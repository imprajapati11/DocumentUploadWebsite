<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'third_party/PHPMailer/src/Exception.php';
require APPPATH . 'third_party/PHPMailer/src/PHPMailer.php';
require APPPATH . 'third_party/PHPMailer/src/SMTP.php';

class ResetPasswordController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('user_model');
         $this->load->library('session');
         $this->load->database();
    }

        public function sendOTP()
        {
            $this->load->library('Phpmailer_lib');
            $this->load->library('session');
            $this->load->database();
     
            $mail = $this->phpmailer_lib->load();
            $email = $this->input->post('email');
            $this->db->where('email',$email);
            $query=$this->db->get('users');
            
                if($query->num_rows() > 0){
                    $this->session->set_userdata('email', $email);
                    
                   try {

                            $mail->isSMTP();
                            $mail->SMTPAuth = true;
                            $mail->Host = 'smtp.gmail.com';
                            $mail->Port = 465;
                            $mail->Username = 'imprajapatimca@gmail.com';
                            $mail->Password = 'wffqkbkmcitrcdmg';
                            $mail->SMTPSecure = 'ssl';
                            $mail->setFrom('imprajapatimca@gmail.com');
                            $mail->Subject = 'Do not reply to this email ( Heavan Spacez PVT. LTD. )';
                            $mail->addReplyTo('imprajapatimca@gmail.com', 'HeavanSpacez');
                            $mail->addAddress($email);
                            $mail->isHTML(true);
                            $otp=rand(100000,999999);
                            
                            $mailContent = "<h1>Heavan Spacez PVT. LTD.</h1>
                            <p>Hello $email,</p>
                            <p>Your OTP is: $otp</p>
                            <p>Please do not share this OTP with anyone. It is confidential and should only be used for authentication purposes.</p>
                            <p>Thank you,</p>
                            <p>Heavan Spacez PVT. LTD.</p>";
                            $mail->Body = $mailContent;
                    
                            if(!$mail->send()){
                                echo 'Mail could not be sent.';
                                echo 'Mailer Error: ' . $mail->ErrorInfo;
                            }else{
                                $sql = "update users set otp='$otp' where email='$email'"; 
                                if ($this->db->query($sql) === TRUE){

                                    //Redirec And msg Print

                                    $this->session->set_flashdata('form_data', $_POST);
                                    $this->session->set_flashdata('sentOtpMsg', 'Success! OTP has been sent. Please check your email');
                                    redirect(base_url('index.php/ResetPasswordController/passwordchange'));
                                }
                            }
                            }
                        catch (Exception $e) {
                                echo "Error sending email: " . $mail->ErrorInfo;
                        }
                    }else{
                        $this->session->set_flashdata('form_data',$_POST);
                        $this->session->set_flashdata('notUser','User not found!');
                        redirect(base_url('index.php/ResetPasswordController/enterEmail'));
                    }
                }
    public function enterEmail(){
        $this->load->view("enter-email");
    }
    public function passwordchange(){
        $this->load->view('reset_password');
    }
    public function resetPassword() {
        $email = $this->input->post('email');
        $otp = $this->input->post('otp');
        $newpassword = $this->input->post('newpassword');
        $confirmnewpassword = $this->input->post('confirmnewpassword');
        $checkEmail=$this->session->userdata('email');
        $checkOtp=$this->session->userdata('otp');
       

        $this->load->database(); 

        $this->db->where('otp', $otp);
        $this->db->where('email', $email);
        $query = $this->db->get('users');
        $row = $query->row();

        if($email === $checkEmail){
            if($otp == $row->otp){
                if ($newpassword === $confirmnewpassword) {
                    $newpassword = md5($newpassword);
                    $data = array('password' => $newpassword);
                    $this->db->where('email', $email);
                    $this->db->update('users', $data);
                    $this->session->set_flashdata('form_data', $_POST);
                    $this->session->set_flashdata('chengePassword', 'Success! Change your Password :)');
                    redirect(base_url('index.php/LoginController/login'));
            }else{
                $this->session->set_flashdata('form_data', $_POST);
                $this->session->set_flashdata('incorrectPassword', 'Password Dont Match! :)');
                redirect(base_url('index.php/ResetPasswordController/passwordchange'));
                //echo "Password Don't Match!";
            }
        }else{
            $this->session->set_flashdata('form_data', $_POST);
            $this->session->set_flashdata('otpError', 'Invalid OTP');
            redirect(base_url('index.php/ResetPasswordController/passwordchange'));
        }
    
    }else{
        $this->session->set_flashdata('form_data', $_POST);
        $this->session->set_flashdata('userNotFound', 'Invalid User');
        redirect(base_url('index.php/ResetPasswordController/passwordchange'));
    }
}

}
?>