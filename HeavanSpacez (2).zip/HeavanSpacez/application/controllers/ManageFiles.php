<?php 
class ManageFiles extends CI_Controller{

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->database();
     }
    public function personalfiledelete($userId){
        if ($userId === null) {
            // echo "User ID is missing";
            exit;
        } else {
            $this->db->where('id', $userId);
            $this->db->delete('goverment_file');

            if ($this->db->affected_rows() > 0) {
                echo '<script>alert("Document Deleted")</script>';
            } else {
                echo '<script>alert("Error")</script>';
            }

            $this->load->view('Users/show-govt-file');      
        }
    }

    public function resultDelete($userId){
        if ($userId === null) {
            exit;
        } else {
            $this->db->where('id', $userId);
            $this->db->delete('result');

            if ($this->db->affected_rows() > 0) {
                echo '<script>alert("Document Deleted")</script>';
            } else {
                echo '<script>alert("Error")</script>';
            }

            $this->load->view('Users/show-result');      
        }
    }
    public function resumeDelete($userId){
        if ($userId === null) {
            exit;
        } else {
            $this->db->where('id', $userId);
            $this->db->delete('resume');

            if ($this->db->affected_rows() > 0) {
                echo '<script>alert("Document Deleted")</script>';
            } else {
                echo '<script>alert("Error")</script>';
            }

            $this->load->view('Users/show-resume');      
        }
    }
}
?>