<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

require APPPATH . 'third_party/PHPMailer/src/Exception.php';
require APPPATH . 'third_party/PHPMailer/src/PHPMailer.php';
require APPPATH . 'third_party/PHPMailer/src/SMTP.php';

class Phpmailer_lib {

    private $mail;

    public function __construct() {
        $this->mail = new PHPMailer(true);
    }

    public function sendOTP($email, $otp) {
        try {

            $this->load->library('Phpmailer_lib');

            $email = $this->input->post('email');
            // $otp = '123456';

            $this->Phpmailer_lib->sendOTP($email, $otp);

            $this->mail->isSMTP();
            $this->mail->SMTPAuth = true;
            $this->mail->Host = 'smtp.gmail.com';
            $this->mail->Port = 465;
            $this->mail->Username = 'imprajapatimca@gmail.com';
            $this->mail->Password = 'wffqkbkmcitrcdmg';
            $this->mail->SMTPSecure = 'ssl';
            $this->mail->setFrom('imprajapatimca@gmail.com');
            $this->mail->addAddress($email);
            $this->mail->Subject = "Do not reply to this email ( Heavan Spacez PVT. LTD. )";
            $otp = rand(100000, 999999);
            $this->mail->Body = 'Your OTP code is: ' . $otp;
            $this->mail->isHTML(true);

            $this->mail->send();
            return true;
        } catch (PHPMailerException $e) {
            echo "Error sending email: {$this->mail->ErrorInfo}";
            return false;
        }
    }
}
