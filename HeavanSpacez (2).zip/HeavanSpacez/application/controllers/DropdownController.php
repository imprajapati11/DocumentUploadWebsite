<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DropdownController extends CI_Controller {

   public function getStates() {
      $country_id = $this->input->post('country_id');

      // Logic to fetch states based on the selected country_id
      // Example:
      $states = $this->db->where('country_id', $country_id)->get('states')->result();

      $options = '';
      foreach ($states as $state) {
         $options .= '<option value="' . $state->id . '">' . $state->name . '</option>';
      }

      echo $options;
   }

   public function getCities() {
      $state_id = $this->input->post('state_id');

      // Logic to fetch cities based on the selected state_id
      // Example:
      $cities = $this->db->where('state_id', $state_id)->get('cities')->result();

      $options = '';
      foreach ($cities as $city) {
         $options .= '<option value="' . $city->id . '">' . $city->name . '</option>';
      }

      echo $options;
   }

}
