<?php

class DocumentUploadController extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->database();
     }

    public function uploadDocument() {
        $userID = $this->session->userdata('user_id');

        if ($this->input->post('submit')) {
            $title = $this->input->post('title');
            $pname = rand(1000, 10000) . "-" . $_FILES["file"]["name"];
            $tname = $_FILES["file"]["tmp_name"];
            $uploads_dir = 'images/uploaded';

            move_uploaded_file($tname, $uploads_dir . '/' . $pname);

            $data = array(
                'file_name' => $title,
                'file_path' => $pname,
                //'upload_date' => date('Y-m-d'),
                'user_id' => $userID
            );

            $this->db->insert('goverment_file', $data);

            $this->session->set_flashdata('form_data', $_POST);
            $this->session->set_flashdata('message', 'Document Successfully Uploaded :)');
            redirect(base_url('index.php/Controller/personal'));

            // redirect(base_url('index.php/RegisterController/register'));

            // echo '<script>alert("Document Successfully Uploaded!")</script>';
               
        } else {
            echo "Error";
        }
    }
    public function viewDocument(){
         $this->load->view('Users/show-govt-file');
    }

    public function result(){
        $userID = $this->session->userdata('user_id');

        if ($this->input->post('submit')) {
            $title = $this->input->post('title');
            $pname = rand(1000, 10000) . "-" . $_FILES["file"]["name"];
            $tname = $_FILES["file"]["tmp_name"];
            $uploads_dir = 'images/uploaded';

            move_uploaded_file($tname, $uploads_dir . '/' . $pname);

            $data = array(
                'file_name' => $title,
                'file_path' => $pname,
                //'upload_date' => date('Y-m-d'),
                'user_id' => $userID
            );

            $this->db->insert('result', $data);

            $this->session->set_flashdata('form_data', $_POST);
            $this->session->set_flashdata('message', 'Document Successfully Uploaded :)');
            redirect(base_url('index.php/Controller/result'));

            // echo '<script>alert("Document Successfully Uploaded!")</script>';
            //     redirect(base_url().'index.php/Controller/result');
        } else {
            echo "Error";
        }
    }
    public function showResult(){
    $this->load->view('Users/show-result');
    }

    public function uploadResume(){

        $userID = $this->session->userdata('user_id');

        if ($this->input->post('submit')) {
            $title = $this->input->post('title');
            $pname = rand(1000, 10000) . "-" . $_FILES["file"]["name"];
            $tname = $_FILES["file"]["tmp_name"];
            $uploads_dir = 'images/uploaded';

            move_uploaded_file($tname, $uploads_dir . '/' . $pname);

            $data = array(
                'file_name' => $title,
                'file_path' => $pname,
                //'upload_date' => date('Y-m-d'),
                'user_id' => $userID
            );

            $this->db->insert('resume', $data);

            $this->session->set_flashdata('form_data', $_POST);
            $this->session->set_flashdata('message', 'Document Successfully Uploaded :)');
            redirect(base_url('index.php/Controller/resume'));

            // echo '<script>alert("Document Successfully Uploaded!")</script>';
            //     redirect(base_url().'index.php/Controller/resume');
        } else {
            echo "Error";
        }
    }
    public function showResume(){
        $this->load->view('Users/show-resume');
    }
}

