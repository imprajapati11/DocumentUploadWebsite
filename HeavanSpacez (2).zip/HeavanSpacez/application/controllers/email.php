<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Email extends CI_Controller{
   
    function  __construct(){
        parent::__construct();
    }
   
    function send(){
        /* Load PHPMailer library */
        $this->load->library('Phpmailer_lib');
       
        /* PHPMailer object */
        $mail = $this->phpmailer_lib->load();
       
        /* SMTP configuration */
       // $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->SMTPAuth = true;
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 465;
        $mail->Username = 'imprajapatimca@gmail.com';
        $mail->Password = 'wffqkbkmcitrcdmg';
        $mail->SMTPSecure = 'ssl';
        $mail->setFrom('imprajapatimca@gmail.com');
       // $mail->addAddress($email);
        $mail->Subject = "Do not reply to this email ( Heavan Spacez PVT. LTD. )";
       
        // $mail->setFrom('imprajapatimca@gmail.com', 'HeavanSpacez');
        $mail->addReplyTo('imprajapatimca@gmail.com', 'HeavanSpacez');
       
        /* Add a recipient */
        $mail->addAddress('22mca048@nirmauni.ac.in');
       
        /* Email subject */
        $mail->Subject = 'Send Email via SMTP using PHPMailer in CodeIgniter';
       
        /* Set email format to HTML */
        $mail->isHTML(true);
       
        /* Email body content */
        $mailContent = "<h1>Send HTML Email using SMTP in CodeIgniter</h1>
        <p>This is a test email sending using SMTP mail server with PHPMailer.</p>";
        $mail->Body = $mailContent;
       
        /* Send email */
        if(!$mail->send()){
            echo 'Mail could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        }else{
            echo 'Mail has been sent';
        }
    }
   
}