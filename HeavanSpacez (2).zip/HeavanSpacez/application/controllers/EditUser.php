<?php 

class EditUser extends CI_Controller{
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->database();
     }
    public function userdata($userId){
        
        $query = $this->db->get_where('users', array('id' => $userId));
        $result = $query->row(); 

        $data['user'] = $result;
       $this->load->view('admin/admin-userupdate', $data);
        // $this->load->view('extra', $data);
    }
    public function editProfile($userId){
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $fname = $this->input->post('fname');
            $lname = $this->input->post('lname');
            $phoneno = $this->input->post('phoneno');
            $email = $this->input->post('email');
            $city = $this->input->post('city');
            $date = date('Y-m-d H:i:s');

            $data=array(
                'fname' => $fname,
                'lname' => $lname,
                'phoneno' => $phoneno,
                'city' => $city,
                'update_date'=>$date,
            );
           $update= $this->db->where('id', $userId)
                            ->update('users', $data);
           if($update->num_rows() > 0){
            $this->session->set_flashdata('form_data', $_POST);
            $this->session->set_flashdata('message', 'Profile Data Updated Successfully.');
            redirect(base_url('index.php/Controller/editdetails'));
           }
        }
    }


    public function edituser($userId){

        $fname = $this->input->post('fname');
        $lname = $this->input->post('lname');
        $phoneno = $this->input->post('phoneno');
        $email = $this->input->post('email');
        $city = $this->input->post('city');   
        $date = date('Y-m-d h:i:sa');    
        $data = array(
 
            'fname' => $fname,
            'lname' => $lname,
            'phoneno' => $phoneno,
            'email' => $email,
            'city' => $city,
            'update_date'=>$date
        );
        $this->db->where('id', $userId);
        $this->db->update('users', $data);

        $this->load->view('admin/admin-usersview');
    
    }

    public function deleteuser($userId){
        // $id = $this->input->get('id');

        if ($userId === null) {
            // User ID is missing
            exit;
        } else {
            $this->db->where('id', $userId);
            $this->db->delete('users');
        
            if ($this->db->affected_rows() > 0) {

                $this->db->where('user_id', $userId);
                $this->db->delete('goverment_file');

                $this->db->where('user_id', $userId);
                $this->db->delete('resume');

                $this->db->where('user_id', $userId);
                $this->db->delete('result');

                $this->db->where('user_id', $userId);
                $this->db->delete('img');
        
                echo '<script>alert("User and associated records deleted")</script>';
            } else {
                // Error deleting user from the users table
                echo '<script>alert("Error deleting user")</script>';
            }        

            $this->load->view('admin/admin-usersview');

           
        }
    }

}

?>