<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class My extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->database();
     }
    
     public function insert_image() {
        $userID = $this->session->userdata('user_id');
        //$file = file_get_contents($_FILES["image"]["tmp_name"]);
        
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            
            $query = $this->db->get_where('img', array('user_id' => $userID));
            if ($query->num_rows() > 0) {
                $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
                $update = "UPDATE img SET img = '$file' WHERE user_id=$userID";
                
                if ($this->db->query($update)) {
                    $this->session->set_flashdata('form_data', $_POST);
                    $this->session->set_flashdata('updateMessage', 'Image Updated Successfully :)');
                    redirect('index.php/Controller/extra');
                    // echo '<script>alert(" uploading the file")</script>';
                    // $this->load->view('Users/extra'); 
                } else {
                    echo '<script>alert("Error")</script>';
                }
            } 
        }else {
                $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
                $data = array(
                    'img' => $file,
                    'user_id' => $userID
                );
               // $this->db->insert('img', $data);

                $query = "INSERT INTO img(img,user_id) VALUES ('$file','$userID')";
                
                $this->session->set_flashdata('form_data', $_POST);
                $this->session->set_flashdata('insertMessage', 'Your Image Inserted successfully :)');
                echo '<script>alert(" uploading the file")</script>';
                redirect('index.php/Controller/extra');
            }
        }        
    

        public function AdminImg() {
            $userID = $this->session->userdata('user_id');
            //$file = file_get_contents($_FILES["image"]["tmp_name"]);
            
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                
                $query = $this->db->get_where('img', array('user_id' => $userID));
                if ($query->num_rows() > 0) {
                    $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
                    $update = "UPDATE img SET img = '$file' WHERE user_id=$userID";
                    
                    if ($this->db->query($update)) {
                        $this->session->set_flashdata('form_data', $_POST);
                        $this->session->set_flashdata('updateMessage', 'Image Updated Successfully :)');
                        redirect('index.php/Controller/Admin');
                        // echo '<script>alert(" uploading the file")</script>';
                        // $this->load->view('Users/extra'); 
                    } else {
                        echo '<script>alert("Error")</script>';
                    }
                } 
            }else {
                    $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
                    $data = array(
                        'img' => $file,
                        'user_id' => $userID
                    );
                   // $this->db->insert('img', $data);
    
                    $query = "INSERT INTO img(img,user_id) VALUES ('$file','$userID')";
                    
                    $this->session->set_flashdata('form_data', $_POST);
                    $this->session->set_flashdata('insertMessage', 'Your Image Inserted successfully :)');
                    echo '<script>alert(" uploading the file")</script>';
                    redirect('index.php/Controller/Admin');
                }
            }        
        
    public function update_profile() {
        $userID = $this->session->userdata('user_id');
        
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $fname = $this->input->post('fname');
            $lname = $this->input->post('lname');
            $phoneno = $this->input->post('phoneno');
            $city = $this->input->post('city');
            $date = date('Y-m-d H:i:s');
            
            $data = array(
                'fname' => $fname,
                'lname' => $lname,
                'phoneno' => $phoneno,
                'city' => $city,
                'update_date' => $date
            );
            
            $this->db->where('id', $userID);
            $update = $this->db->update('users', $data);
            
            if ($update) {
                $this->session->set_flashdata('form_data', $_POST);
                $this->session->set_flashdata('message', 'Profile Data Updated Successfully.');
                redirect('index.php/Controller/extra');
            }
        }
    }

    public function AdminProfile() {
        $userID = $this->session->userdata('user_id');
        
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $fname = $this->input->post('fname');
            $lname = $this->input->post('lname');
            $phoneno = $this->input->post('phoneno');
            $city = $this->input->post('city');
            $date = date('Y-m-d H:i:s');
            
            $data = array(
                'fname' => $fname,
                'lname' => $lname,
                'phoneno' => $phoneno,
                'city' => $city,
                'update_date' => $date
            );
            
            $this->db->where('id', $userID);
            $update = $this->db->update('users', $data);
            
            if ($update) {
                $this->session->set_flashdata('form_data', $_POST);
                $this->session->set_flashdata('message', 'Profile Data Updated Successfully.');
                redirect('index.php/Controller/Admin');
            }
        }
    }
    
    public function view(){
        $this->load->view('Users/extra');
    }
    public function editdetails() {
        if ($this->session->flashdata('message')) {
            $data['message'] = $this->session->flashdata('message');
        }
        
        $this->load->view('editdetails_view', $data); // Replace 'editdetails_view' with your view file name
    }
}
?>
