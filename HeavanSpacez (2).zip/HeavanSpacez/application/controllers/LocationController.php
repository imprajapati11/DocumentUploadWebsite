<?php

class LocationController extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('LocationModel');
    }

    public function getStates() {
        $countryId = $this->input->post('country_id');
        $states = $this->LocationModel->getStatesByCountry($countryId);
        echo json_encode($states);
    }

    public function getCities() {
        $stateId = $this->input->post('state_id');
        $cities = $this->LocationModel->getCitiesByState($stateId);
        echo json_encode($cities);
    }
    // public function index() {
    //     $data['countries'] = $this->db->get('countries')->result_array();
    //     $this->load->view('extra', $data);
    // }
    // public function selectcity(){
    //     // $this->load->view('extra');
    //     $data['countries'] = $this->db->get('countries')->result_array();
    //     $this->load->view('extra', $data);
    // }
}