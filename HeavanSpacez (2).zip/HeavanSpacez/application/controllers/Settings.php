<?php

class Settings extends CI_Controller{

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->database();
     }
    public function basicdetails(){
        $this->load->view('admin/update-profile');
    } 
    public function editimg(){
        $this->load->view('admin/admin-img');
    }
    public function changepassword(){
        $this->load->view('admin/pwd-change');
    }
}

?>