<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends CI_Controller {

   public function login() {
      
      if (!$this->session->userdata('logged_in')){
         
      $this->load->view('user-login');
      }else{
      $this->load->view('admin/admin-dashboard');

         // $isAdmin=$this->session->userdata('isAdmin');
         // if ($isAdmin > 0) {
         //    $this->load->view('admin/admin-dashboard');     
         // } else {
         //    $this->load->view('Users/dashboard');
         // }
      }
      // $this->session->start();
   }

   public function __construct() {
      parent::__construct();
      $this->load->library('session');
      $this->load->database();
   }
   public function logout() {
      $this->session->sess_destroy();
      redirect(base_url().'index.php/Welcome/index');
  }

   public function process() {


     
      $email = $this->input->post('email');
      $password = $this->input->post('password');
       $password = md5($password);
       

      $query = $this->db->select('id, isAdmin')
                        ->from('users')
                        ->where('email', $email)
                        ->where('password', $password)
                        ->get();

      $result = $query->row();

      if ($result) {
         $user_id = $result->id;
         $isAdmin = $result->isAdmin;

         $this->session->set_userdata('user_id', $user_id);
         $this->session->set_userdata('isAdmin', $isAdmin);
         $this->session->set_userdata('last_timestamp', time());
         
         
         if ($isAdmin > 0) {
            $this->session->set_userdata('logged_in', true);
            $this->load->view('admin/admin-dashboard');     
         } else {
            $this->session->set_userdata('logged_in', true);
            $this->load->view('Users/dashboard');
         }
      } else {
         $this->session->set_flashdata('form_data',$_POST);
         $this->session->set_flashdata('notValid','Username Or Password Incorrect');
         redirect(base_url().'index.php/LoginController/login');
      }
   }
}
