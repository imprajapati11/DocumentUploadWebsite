<?php 

class Controller extends CI_Controller{

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->database();
     }
    public function dashboard(){
        $this->load->view('Users/dashboard');
    }
    public function personal(){
        $this->load->view('Users/goverment-document');
    }

    public function result(){
        $this->load->view('Users/result');
    }
    public function resume(){
        $this->load->view('Users/resume');
    }
    public function extra(){
        $this->load->view('Users/extra');
    }
    public function Admin(){
        $this->load->view('admin/admin-editprofile');
    }
    public function others(){
        $this->load->view('Users/others');
    }
    public function feedback(){
        $this->load->view('Users/feedback');
    }
    public function sendFeedback(){
        $fname = $this->input->post('fname');
        $lname = $this->input->post('lname');
        $phoneno = $this->input->post('phoneno');
        $email= $this->input->post('email');
        $feedback= $this->input->post('msg');

        $data = array(

            'fname'=>$fname,
            'lname'=>$lname,
            'phoneno'=>$phoneno,
            'email'=>$email,
            'msg' =>$feedback,
        );
        $result = $this ->db->insert('feedback',$data);
        if($result){
            $this->session->set_flashdata('form_data', $_POST);
            $this->session->set_flashdata('message', 'Thank you:) If you have any more questions, feel free to ask. Im here to help!:)');
            redirect(base_url('index.php/Controller/feedback'));
            // redirect("index.php/Controller/feedback");
        }else{
            echo "Some Error";
        }
    }
    public function editdetails(){
        $this->load->view('Users/update-profile');
    }
    public function editimg(){
        $this->load->view('Users/img');
    }
    public function changepassword(){
        $this->load->view('Users/pwd-change');
    }       
    public function searchFiles() {
        $search_box = $this->input->post('search_box');
        $userID = $this->session->userdata('user_id');

        $sql = "SELECT * FROM `goverment_file`
                WHERE file_name LIKE '%" . $search_box . "%' AND user_id='$userID'
                UNION
                SELECT * FROM `result`
                WHERE file_name LIKE '%" . $search_box . "%' AND user_id='$userID'
                UNION
                SELECT * FROM `resume`
                WHERE file_name LIKE '%" . $search_box . "%' AND user_id='$userID'";

        $query = $this->db->query($sql);
        $results = $query->result();

        $data['results'] = $results;
        $this->load->view('Users/document-search', $data);
    }
}
?>