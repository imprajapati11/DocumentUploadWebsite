<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ImageController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->library('session');
        $this->load->helper('url');
    }

    public function index() {
        if (!$this->session->userdata('user_id')) {
            redirect('user-login');
        }

        $this->load->view('upload_image');
    }

    public function insertImage() {
        if (!$this->session->userdata('user_id')) {
            redirect('user-login');
        }

        $userID = $this->session->userdata('user_id');

        $config['upload_path'] = './uploads/';  // Specify the upload path
        $config['allowed_types'] = 'jpg|jpeg|png';  // Allowed file types
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('image')) {
            $error = $this->upload->display_errors();
            echo "<script>alert('$error');</script>";
        } else {
            $fileData = $this->upload->data();
            $file = file_get_contents($fileData['full_path']);

            $query = $this->db->get_where('img', array('user_id' => $userID));
            if ($query->num_rows() > 0) {
                $updateData = array('img' => $file);
                $this->db->where('user_id', $userID)->update('img', $updateData);
                // echo "<script>alert('Update Your Image');</script>";
                // redirect(base_url().'index.php/Controller/editimg'); 

                $this->session->set_flashdata('form_data', $_POST);
                $this->session->set_flashdata('updateMessage', 'Image Updated Successfully.:)');
                redirect(base_url('index.php/Controller/editimg'));

            } else {
                $insertData = array(
                    'img' => $file,
                    'user_id' => $userID
                );
                $q=$this->db->insert('img', $insertData);
                if($q->num_rows() > 0){
                    $this->session->set_flashdata('form_data', $_POST);
                    $this->session->set_flashdata('insertMessage', 'Your Image Inserted successfully.:)');
                    redirect(base_url('index.php/Controller/editimg'));
                    //$this->session->set_flashdata('message','Your Data Inserted successfully.');
                }
            }
        }
    }
}
