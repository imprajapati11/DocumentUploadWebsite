<?php 

class AdminRedirect extends CI_Controller{

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->database();
     }
     public function admin(){
      $this->load->view('admin/admin-dashboard');
     }   
     public function adduser(){
      $data['countries'] = $this->db->get('countries')->result_array();
      $this->load->view('admin/admin-adduser', $data);
      //   $this->load->view('admin/admin-adduser'); 
     }

     public function feedback(){
        $this->load->view('admin/admin-viewfeedback');
     }

     public function personal(){
        $this->load->view('admin/admin-personal-file');
     }
     public function news(){
      $this->load->view('admin/admin-news');
     }
         
     public function result(){
        $this->load->view('admin/admin-result');
     }
     
     public function resume(){
        $this->load->view('admin/admin-resume');
     }

     public function useredit(){
      $this->load->view('admin/admin-userupdate');
     }

    public function userlist(){
        $this->load->view('admin/admin-usersview'); 
    }

    public function serach(){

         $search_box = $this->input->post('search_box');

         $this->db->select('*');
         $this->db->from('goverment_file');
         $this->db->join('users', 'goverment_file.user_id = users.id', 'inner');
         $this->db->like('goverment_file.file_name', $search_box);
         $query1 = $this->db->get();

         $this->db->select('*');
         $this->db->from('result');
         $this->db->join('users', 'result.user_id = users.id', 'inner');
         $this->db->like('result.file_name', $search_box);
         $query2 = $this->db->get();

         $this->db->select('*');
         $this->db->from('resume');
         $this->db->join('users', 'resume.user_id = users.id', 'inner');
         $this->db->like('resume.file_name', $search_box);
         $query3 = $this->db->get();

         $results = $query1->result_array();
         $results = array_merge($results, $query2->result_array());
         $results = array_merge($results, $query3->result_array());

         $data['results'] = $results;
         $this->load->view('admin/admin-docusearch', $data);
         
     }

     public function viewDocuments() {
      $this->db->select('users.fname, goverment_file.file_name, goverment_file.file_path, goverment_file.upload_date');
      $this->db->from('users');
      $this->db->join('goverment_file', 'users.id = goverment_file.user_id');
      $this->db->order_by('users.fname');
      $query = $this->db->get();
      $data['documents'] = $query->result();
      
      $this->load->view('admin/admin-personal-file', $data);
      }

    }


?>