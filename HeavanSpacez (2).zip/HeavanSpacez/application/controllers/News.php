<?php 
class News extends CI_Controller{
    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->database();
     }

    public function newsadd(){
        $data['cities'] = $this->db->get('cities')->result_array();
        $this->load->view('admin/admin-addnews',$data);
    }
    public function add(){
        if(isset($_POST['submit'])){
            $header = $_POST['heading']; 
            $information = $_POST['details'];
            $city = $_POST['city'];
            $file = file_get_contents($_FILES['image']['tmp_name']); 
            $extra=$_POST['extra'];
            $link=$_POST['link_description'];
            $date = date('Y-m-d H:i:s');

            $data = array(
                'header' => $header,
                'information' => $information,
                'location' => $city,
                'img' => $file,
                'date' => $date,
                'extra' => $extra,
                'link_description' => $link
            );

            $this->db->insert('news', $data);

            if($this->db->affected_rows() > 0){
                $this->session->set_flashdata('form_data', $_POST);
                $this->session->set_flashdata('addUser', 'News Successfully Added');
                redirect(base_url('index.php/News/newsadd'));
            } else {
                echo '<script>alert("Some Error!!")</script>';
            }
        }
}

public function deletenews($id)
    {
        if ($id === null) {
            exit;
        } else {
            $this->db->where('id', $id);
            $this->db->delete('news');
        
            if ($this->db->affected_rows() > 0) {
        
                echo '<script>alert("News deleted")</script>';
            } else {
                // Error deleting user from the users table
                echo '<script>alert("Error deleting user")</script>';
            }        

            $this->load->view('admin/admin-news');     
        }
    }

    public function editnews($id){
        $query = $this->db->get_where('news', array('id' => $id));
        $result = $query->row(); 

        $data['news'] = $result;
    $this->load->view('admin/admin-editnews',$data);
    }

    public function edit($id){

        $header = $_POST['heading']; 
            $information = $_POST['details'];
            $city = $_POST['city'];
            $file = file_get_contents($_FILES['image']['tmp_name']); 
            $extra=$_POST['extra'];
            $link=$_POST['link_description'];
            $date = date('Y-m-d H:i:s');

            $data = array(
                'header' => $header,
                'information' => $information,
                'location' => $city,
                'img' => $file,
                'extra' => $extra,
                'link_description' => $link,
                'edit_date' => $date
            );

            $this->db->where('id',$id);
            $this->db->update('news',$data);

            redirect(base_url('index.php/AdminRedirect/news'));

    }


    public function getAllNews() {
        $data['news'] = $this->db->get('news')->result_array();
    
        $this->load->view('Users/extra', $data);
      }
    
      public function getNewsByDate($date) {
        // Retrieve news articles for a specific date
    $data['news'] = $this->db->get_where('news', array('date' => $date))->result_array();
    
    $this->load->view('Users/extra', $data);
      }


}

?>