<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin extends CI_Controller {
public function index()
	{
		$this->load->library('form_validation');
        $this->form_validation->set_rules('email','Username','required|valid_email');
        $this->form_validation->set_rules('password','Password','required|min_length[3]');

        if($this->form_validation->run()){
            $email=$this->input->post('email');
            $password=$this->input->post('password');
            $this->load->model('loginmodel');
            $userID=$this->loginmodel->isvalidate($email,$password);
           if($userID>0){
                // echo "Details Match";
                
                $this->load->library('session');
                $userID=$this->session->set_userdata('id');
                $data['id'] = $userID;
                $this->load->view('extra',$data);
                
           }else{
                echo "Details Not Match";
           }
        }else{
            // $this->load->view('user-login');
            echo validation_errors();
        }
	}
	
}
