<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RegisterController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('user_model');
         $this->load->library('session');
    }
    

    public function register() {
        $data['countries'] = $this->db->get('countries')->result_array();
         $this->load->view('user-register', $data);
        // $this->load->view('extra', $data);
        // $this->load->view('user-register');
    }

    public function process() {

        $fname = $this->input->post('fname');
        $lname = $this->input->post('lname');
        $phoneno = $this->input->post('phoneno');
        $email = $this->input->post('email');
        $city = $this->input->post('city');
        $password = $this->input->post('password');

        //$checkUser=$this->db->select('user',$email);

        $this->db->where('email', $email);
        $query = $this->db->get('users');
    
        if ($query->num_rows() > 0) {
           $this->session->set_flashdata('form_data', $_POST);
           $this->session->set_flashdata('message', 'Already registered');
           redirect(base_url('index.php/RegisterController/register'));
                }else{
    
            $data = array(
               'fname' => $fname,
               'lname' => $lname,
               'phoneno' => $phoneno,
               'email' => $email,
               'city' => $city,
               'password' => md5($password),
               'registration_date' => date('Y-m-d H:i:sa')
            );

            $result = $this->db->insert('users', $data);

            if ($result) {
                $this->session->set_flashdata('form_data', $_POST);
                $this->session->set_flashdata('trueMsg', 'Success! Your account is now created and you can login.');
                redirect(base_url('index.php/LoginController/login'));
            //    echo '<script>alert("Your Account has been Successfully Created :)")</script>';
            //    $this->load->view('user-login');
              
            } else {
                echo "Error inserting record into the database.";
            }
        }
    }
    }

