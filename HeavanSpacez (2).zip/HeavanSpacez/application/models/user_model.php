<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    public function register_user($data) {
        return $this->db->insert('users', $data);
    }

    public function login_user($email,$password){
        return $this->db->select('id, isAdmin')
                        ->from('users')
                        ->where('email', $email)
                        ->where('password', $password)
                        ->get();    
    }
}
