<?php
// LocationModel.php

class LocationModel extends CI_Model {
    public function getStatesByCountry($countryId) {
        $this->db->where('country_id', $countryId);
        return $this->db->get('states')->result_array();
    }

    public function getCitiesByState($stateId) {
        $this->db->where('state_id', $stateId);
        return $this->db->get('cities')->result_array();
    }
}