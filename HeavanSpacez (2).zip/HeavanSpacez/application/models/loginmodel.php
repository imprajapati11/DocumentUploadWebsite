<?php

class loginmodel extends CI_model{

    public function isvalidate($email,$password){
        // $this->db->where('email', $email);
        // $this->db->where('password', $password);
        // $query = $this->db->get('login');
  
        // if ($query->num_rows() == 1) {
        //    return $query->row();
        // } else {
        //    return false;
        // }


        $query=$this->db->where(['email'=>$email,'password'=>$password])
                    ->get('login');
                    // echo "<pre>";
                    // print_r();
                    // exit;
            if($query->num_rows()>0){
                return $query->row()->id;
            }else{
                return false;
            }
    }

}

?>