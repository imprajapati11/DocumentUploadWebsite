<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UserModel extends CI_Model {

   public function __construct() {
      parent::__construct();
   }

   public function authenticate($email, $password) {
      $this->db->where('email', $email);
      $this->db->where('password', $password);
      $query = $this->db->get('login');

      if ($query->num_rows() > 0) {
         return $query->row();
      } else {
         return false;
      }
   }

}
