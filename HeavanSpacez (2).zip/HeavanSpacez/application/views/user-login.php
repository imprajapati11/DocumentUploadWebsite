<!DOCTYPE html>
<html lang="en">
<head>
	<title>HeavanSpacez Login</title>
	
	<link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
	<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
	<link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
	<link rel="manifest" href="/site.webmanifest">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">


	<link rel="stylesheet" type="text/css" href="<?= base_url("vendor/bootstrap/css/bootstrap.min.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("fonts/font-awesome-4.7.0/css/font-awesome.min.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("fonts/Linearicons-Free-v1.0.0/icon-font.min.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("vendor/animate/animate.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("vendor/css-hamburgers/hamburgers.min.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("vendor/animsition/css/animsition.min.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("Vendor/select2/select2.min.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("vendor/daterangepicker/daterangepicker.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("css/util.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("css/main.css");?>">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- <script>
        $(document).ready(function() {
            // Show the message for 3 seconds
            setTimeout(function() {
                $("#msg").fadeOut("slow");
            }, 3000);
        });

		$(document).ready(function() {
            // Show the message for 3 seconds
            setTimeout(function() {
                $("#emailmsg").fadeOut("slow");
            }, 3000);
        });
    </script> -->

<style>

	
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 120px;
  height: 120px;
  margin: -76px 0 0 -76px;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
.animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
}

@-webkit-keyframes animatebottom {
  from { bottom:-100px; opacity:0 } 
  to { bottom:0px; opacity:1 }
}

@keyframes animatebottom { 
  from{ bottom:-100px; opacity:0 } 
  to{ bottom:0; opacity:1 }
}

#myDiv {
  display: none;
  text-align: center;
}
</style>

</head>
<body style="margin:0;">

<div  class="animate-bottom">
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-110 p-r-110 p-t-62 p-b-33" style="border: 20px;
            border: 2px solid black;
            border-radius: 50px;
			box-shadow: 1	px 2px 3px 4px rgba(12,12,12,0.2);
			">
			<?php echo form_open('index.php/LoginController/process',['class'=>'login100-form validate-form flex-sb flex-w','onsubmit'=>'return validateForm()']);?>
				<!-- <form class="login100-form validate-form flex-sb flex-w" onsubmit="return validateForm()"  action="base_url('admin/index')" method="POST"> -->
					<span class="login100-form-title p-b-53">
                    <img src="<?= base_url("images/HS.png");?>" style="  height: 90px;">
					</span>

					<span class="login100-form-title p-b-53">
						
					<?php if ($this->session->flashdata('trueMsg')): ?>
						<div class="alert alert-success alert-dismissible fade show" role="alert">
							<?php echo $this->session->flashdata('trueMsg'); ?>
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
								</button>
							</div>
					<?php endif; ?>
					
					<?php if ($this->session->flashdata('chengePassword')): ?>
						<div class="alert alert-success alert-dismissible fade show" role="alert">
							<?php echo $this->session->flashdata('chengePassword'); ?>
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
								</button>
							</div>
					<?php endif; ?>

					<?php if ($this->session->flashdata('notValid')): ?>
						<div class="alert alert-danger alert-dismissible fade show" role="alert">
						<?php echo $this->session->flashdata('notValid'); ?>
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">×</span>
							</button>
						</div>
					<?php endif; ?>
				
					<?php if ($this->session->flashdata('sessionError')): ?>
						<div class="alert alert-danger alert-dismissible fade show" role="alert">
						<?php echo $this->session->flashdata('sessionError'); ?>
							<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">×</span>
							</button>
						</div>
					<?php endif; ?>
					</span>
				
					<div class="p-t-31 p-b-9" style="margin-top :-25px">
						<span class="txt1">
						Username
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Username is required">
						
						<!-- <input class="input100" type="text" id="email" name="email" placeholder="Enter EmailID"> -->
						<?php echo form_input(['class'=>'input100','placeholder'=>'Enter EmailID','type'=>'text','id'=>'email','name'=>'email','value'=>set_value('email')]); ?>
						<span class="focus-input100"></span>
						<?php echo form_error('email'); ?>
                        <span id="emailError" style="color: #8C2F00; font-size: 12px"></span>
					</div>
					
					<div class="p-t-13 p-b-9">
						<span class="txt1">
							Password
						</span>

						<a href="<?php echo base_url('index.php/ResetPasswordController/enterEmail')?>" class="txt2 bo1 m-l-5">
							Forgot?
						</a>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<!-- <input class="input100" type="password" id="password" name="password" placeholder="Enter Password"> -->
						<?php echo form_password(['class'=>'input100','placeholder'=>'Enter Password','type'=>'password','id'=>'password','name'=>'password','value'=>set_value('password')]); ?>
						<span class="focus-input100"></span>
						<?php echo form_error('password');?>
                        <span id="passwordError" style="color: #8C2F00; font-size: 12px"></span>
					</div>

					<div class="container-login100-form-btn m-t-17">
						<button class="login100-form-btn" name="submit">
							Sign In
						</button>
						
					</div>
					<div class="w-full text-center p-t-55">
						<span class="txt2" >
							Not a member?
						</span>
						
						<a href="<?= base_url();?>index.php/RegisterController/register" class="txt2 bo1">
							Sign up now
						</a>

						
					</div>	
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	</div>
	
	<script src="<?= base_url("vendor/jquery/jquery-3.2.1.min.js");?>"></script>
	<script src="<?= base_url("vendor/animsition/js/animsition.min.js");?>"></script>
	<script src="<?= base_url("vendor/bootstrap/js/popper.js");?>"></script>
	<script src="<?= base_url("vendor/bootstrap/js/bootstrap.min.js");?>"></script>
	<script src="<?= base_url("vendor/daterangepicker/moment.min.js");?>"></script>
	<script src="<?= base_url("vendor/daterangepicker/daterangepicker.js");?>"></script>
	<script src="<?= base_url("vendor/countdowntime/countdowntime.js");?>"></script>
	<script src="<?= base_url("js/main.js");?>"></script>

	

<!-- <script>

    function validateForm(){
        var email = document.getElementById("email").value;
        var password = document.getElementById("password").value;

        if(email===""){
            document.getElementById("emailError").innerHTML = "*Email is Required." ;
            return false;
        }
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            document.getElementById("emailError").innerHTML = "*Invalid email format.";
            return false;
  }

        if(password===""){
            document.getElementById("passwordError").innerHTML = "*Password is Required." ;
            return false;
        }
    }

</script>  -->

<script>
  function validateEmail(email) {
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  function validateForm() {
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    if (email === "") {
      document.getElementById("emailError").innerHTML = "*Email is Required.";
      return false;
    } else if (!validateEmail(email)) {
      document.getElementById("emailError").innerHTML = "*Invalid email format.";
      return false;
    } else {
      document.getElementById("emailError").innerHTML = "";
    }

    if (password === "") {
      document.getElementById("passwordError").innerHTML = "*Password is Required.";
      return false;
    } else {
      document.getElementById("passwordError").innerHTML = "";
    }

    return true;
  }

  document.getElementById("email").addEventListener("keyup", function () {
    validateForm();
  });

  document.getElementById("password").addEventListener("keyup", function () {
    validateForm();
  });
</script>

<!-- </script> -->


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

</body>
</html>