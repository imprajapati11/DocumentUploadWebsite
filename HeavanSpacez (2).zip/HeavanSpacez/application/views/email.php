<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require APPPATH . 'third_party/PHPMailer/src/Exception.php';
require APPPATH . 'third_party/PHPMailer/src/PHPMailer.php';
require APPPATH . 'third_party/PHPMailer/src/SMTP.php';


include("User/DbConnection.php");

if(isset($_POST['submit'])){

 
  $email=$_POST['email'];
  $sql = "SELECT * FROM `users` where email = '$email'";
  $res = mysqli_query($con,$sql);
  $row=mysqli_fetch_assoc($res);
    if(mysqli_num_rows($res) > 0){
        $row = mysqli_fetch_assoc($res);
        if($email !== isset($row['email'])){

            $mail = new PHPMailer(true);
            $mail->isSMTP();   
            $mail->SMTPAuth   = true;  
            $mail->Host       = 'smtp.gmail.com';
            $mail->Port       = 465;
            $mail->Username   = 'imprajapatimca@gmail.com';  
            $mail->Password   = 'wffqkbkmcitrcdmg';
            $mail->SMTPSecure = 'ssl';    
            $mail->setFrom('imprajapatimca@gmail.com');  
            $mail->addAddress($_POST["email"]);    
            $mail->Subject  = "Do not reply to this email ( Heavan Spacez PVT. LTD. )";
            $otp = rand(100000, 999999);
            $mail->Body = 'Your OTP code is: ' . $otp;
          
            $mail->isHTML(true); 
          
            $mail->send();
          
            // $email=$_POST['email'];
          
            $sql = "update users set otp='$otp' where email='$email'"; 
          
            if ($con->query($sql) === TRUE) {
              header('location:reset_password.php');
              $_SESSION['otpmsg']="OTP send Your email!!";
          } else {
              echo "Error: ";
          }


        }
        }else{
            header('location:user-login.php');
            $_SESSION['notuser']="Not Registed User!!";
    }


}

?>