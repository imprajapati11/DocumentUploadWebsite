<?php 
$hostname="localhost";
$username="root";
$password="";
$db_name="documentupload";

$conn= mysqli_connect($hostname, $username, $password, $db_name);

$state_id = $_POST['state_id'];
$query= "select * from cities where state_id='".$state_id."' order by name ASC";
$result= mysqli_query($conn,$query);

while ($row= mysqli_fetch_array($result)) {
	?>
	<option value='<?php echo $row['name'] ?>'><?php echo $row['name']; ?></option>;
<?php } ?>