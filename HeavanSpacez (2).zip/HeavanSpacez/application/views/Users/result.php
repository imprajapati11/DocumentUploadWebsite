<?php $userID=$this->session->userdata('user_id');?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>HeavanSpacez Result</title>
      
      <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
      <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
      <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
      <link rel="stylesheet" href="<?= base_url('assets/css/fontawesome.css');?>">
      <link rel="stylesheet" href="<?= base_url('assets/css/animated.css');?>">
      <link rel="stylesheet" href="<?= base_url('assets/css/owl.css');?>">

      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

      <style>

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}

.container {
  height: 100vh;
  width: 100%;
  align-items: center;
  display: flex;
  margin-left: -100px;
  justify-content: center;
}

.card {
  margin-top: auto;
  border-radius: 10px;
  box-shadow: 0 5px 10px 0 rgba(0, 0, 0, 0.3);
  width: 460px;
  height: 450px;
  background-color: #ffffff;
  padding: 10px 30px 40px;
}

.card h3 {
  font-size: 22px;
  font-weight: 600;
  padding: .2em;
}

.drop_box {

  padding: 35px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  border: 3px dotted #a3a3a3;
  border-radius: 5px;
}

.drop_box h4 {
  font-size: 16px;
  font-weight: 400;
  color: #2e2e2e;
}

.drop_box p {
  margin-top: 10px;
  margin-bottom: 20px;
  font-size: 12px;
  color: #a3a3a3;
}

.btn {
  text-decoration: none;
  background-color: #005af0;
  color: #ffffff;
  padding: 10px 20px;
  border: none;
  outline: none;
  transition: 0.3s;
}

.btn:hover{
  text-decoration: none;
  background-color: #ffffff;
  color: #005af0;
  padding: 10px 20px;
  border: none;
  outline: 1px solid #010101;
}
</style>

</head>
<body style="background-color: #fff;">

    <?php include('header.php');?>
    <?php include('sidebar.php');?> 

<div class="container">
<p style="margin-top: 400px;">
 <h2>
    <?php

include("DbConnection.php"); 

$sql = "SELECT count(*) FROM result where user_id='$userID' ";
$result = $con->query($sql);


while($row = mysqli_fetch_array($result)) {
  echo  'Total Document Uploaded: <b>  ' . $row['count(*)'] .'</b></span>';
	
}

$con->close();
?>

<br>
 <a href="<?php echo base_url().'index.php/DocumentUploadController/showResult'?>"><button class="btn"><i class="fa-solid fa-eye"></i>   View Document</button></a>
 </h2>


</p>
<form method="post"  enctype="multipart/form-data" action="<?php echo site_url('index.php/DocumentUploadController/result'); ?>" style="margin-top: 150px; margin-left: 50px;">
  <div class="card" style="margin-right:80px; margin-top: -200px;">
    <h3>Result Upload</h3>
    <div class="drop_box">
 
    <input type="text" name="title" id="title" placeholder="Title..." style="
            margin: 10px 0;
            width: 50%;
            background-color: var(--light-bg);
            border-color: #010101;
            outline: none;
            padding: 12px 20px;
            cursor: pointer;
            font-size: 1.5em;
          "> 
            <span id="titleerror" style="color: #8C2F00;"></span>


    <input type="file" accept=".png,.jpg,.jpeg,.doc,.docx,.pdf" name="file" id="file" style="
            margin: 10px 0;
            width: 100%;
            border-color: #010101;
            outline: none;
            padding: 12px 20px;
            cursor: pointer;
            background-color: var(--main-color);
            color: #ffffff;
            border-radius: 5px;
           font-size: 1.6em;
          ">
      <p style="color: #8B0000; font-size: 15px;"><b>*Files Supported: JPEG, JPG, PNG, PDF, TEXT</b></p>
      <!-- <input type="file" name="file" accept=".png,.jpg,.jpeg,.doc,.docx,.pdf" id="fileID" > -->

   
    
      <input type="submit" name="submit" value="Upload" style="
      background-color: var(--main-color);
      font-size: 20px;
      color: #ffffff;
      border-radius: 5px;
      margin: 10px 0;
      width: 50%;
      border-color: #010101;
      outline: none;
      padding: 12px 20px;
      cursor: pointer;
      "> 
      
      <?php if ($this->session->flashdata('message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-bottom: -1em; font-size: 1.5em;">
                  <?php echo $this->session->flashdata('message'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close" style="font-size: 1.5em;">
                      <span aria-hidden="true">×</span>
                    </button>
                </div>
      <?php endif; ?>
    </div>
  </div>
</form>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

<?php 
include("footer.php");
?>
</body>
</html>

