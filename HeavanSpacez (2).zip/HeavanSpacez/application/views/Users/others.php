<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
   <meta http-equiv="refresh" content="900"> 
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
   <title>HeavanSpacez News Portal</title>
   <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url("images/apple-touch-icon.png")?>">
	<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url("images/favicon-32x32.png")?>">
	<link rel="icon" type="image/png" sizes="16x16" href="<?= base_url("images/favicon-16x16.png")?>">

<style>
  
.wrapper{
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-left: -65x;
    width: 1400px;
}
.background-container{
    width: 100%;
    min-height: 60vh;
    display: flex; 
}
.bg-1{
    flex: 1;
    /* background-color: rgb(180, 243, 175); */
}
.bg-2{
    flex: 1;
    /* background-color: rgb(163, 236, 240); */
}
.about-container{
    width: 100%;
    margin-left: -50px;
    min-height: 50vh;
    position: absolute;
    background-color: #f5f5f5;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px 40px;
    border-radius: 5px;
    /* margin-bottom: 175px; */
}
.image-container{
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-left: -15em;
}
.image-container img {
    width: 500px;
    height: 500px;
    margin: 20px;
    border-radius: 10px;
}
.text-container{
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    flex-direction: column;
    font-size: 22px;
    margin-left: -5em;
}
.text-container h1{
    font-size: 70px;
    padding: 20px 0px;
}
/* .text-container a{
    text-decoration: none;
    padding: 12px;
    margin: 50px 0px;
    background-color: rebeccapurple;
    border: 2px solid transparent;
    color: white;
    border-radius: 5px;
    transition: .3s all ease;
}
.text-container a:hover{
    background-color: transparent;
    color: black;
    border: 2px solid rebeccapurple;
} */
@media screen and (max-width: 1600px){
    .about-container{
        width: 90%;
    }
    .image-container img{
        width: 400px;
        height: 400px;
    }
    .text-container h1{
        font-size: 50px;
    }
}
@media screen and (max-width: 1100px){
    .about-container{
        flex-direction: column;
    }
    .image-container img{
        width: 300px;
        height: 300px;
    }
    .text-container {
        align-items: center;
    }
}

@font-face {
	font-family: 'Langdon';
	src: url('../fonts/Langdon.otf');
}

@font-face {
	font-family: 'Reckoner';
	src: url('../fonts/Reckoner.ttf');
}

.main{
	margin: 50px;
    margin-left: -10em;
}

.presenter{
	position: relative;

  	background-size: 1000px 462px;

	width: 100%;
	height: 160px;
	margin: 0 auto;
}

.logoi{
	background-image: url('https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhwpIamohskNyFV8D0VTNRudQk2IB7tLRizIAji-5Xu0-_zdWcuQ83tixgHwOmkm0l07CoSlrYWexpUcds3Es59j0cvFAGxn1NEKTRnvFN9irdqAhnfOzgQ9Qbtyl4JKNX9Dmi53sTvShz71QpYyxiYwPU3wwWle4bxoN59BjNZpkCtUEdRMmwwjUZMGiY/s1600/11.png');
	background-size: 260px 215px;
	text-align: center;
	padding: 15px 10px 13px 10px;
	border: 4px solid #3a3939;
	float: left;
	position: absolute;
	left: 60px;
	bottom: -23px;
	z-index: 200;
}

.logoi h1{
	font-family: 'Langdon';
	text-transform: uppercase;
	color: black;
	margin: 0;
}

.logoi #breaking{
	font-size: 1.5em;
	margin-top: 10px;
	letter-spacing: 5px;
}

.logoi #news{
	font-size: 3.2em;
	letter-spacing: 5px;
}

.logoi hr{
	border: 3px solid black;
	margin: 0;
}

.container{
	width: 100%;
	overflow: hidden;
	box-sizing: border-box;
	height: 40px;
	position: relative;
	cursor: pointer;
	margin: 0 auto;
	background: black;
}

#panel{
	bottom: 25px;
	position: absolute;
}

.marquee, *[class^="marquee"] {
	white-space: nowrap;
    direction="down"
  width="250"
  height="200"
  behavior="alternate"
  style="border:solid"
}

.content {
  margin: 0;
}

.content li {
    padding: 5px 5px 5px 5px;
    color: #fff;
	height: 35px;
	position: absolute;
	list-style-type: none;
}

.content h1{
	color: white;
	font-family: 'Reckoner';
	letter-spacing: 9px;
	font-size: 2em;
	margin: 0 0 0 0;
	display: inline;
	vertical-align: bottom;
}

.content img{
	width: 30px;
	padding: 3px 40px 0 35px;
}
/* 
footer {
	margin-top: 100px;
}

footer h2{
	text-align: center;
	font-family: 'Langdon';
	font-size: 1em;
	color: white;
	text-transform: uppercase;
	letter-spacing: 4px;
}

footer h2 a{
	text-decoration: none;
	color: #b70000;
	font-size: 1.5em;
}

footer h2 a:hover{
	color: #b55353;
} */
#jquery-script-menu{position:absolute;height:90px;width:100%;top:0;left:0;border-top:5px solid #316594;background:#fff;-moz-box-shadow:0 2px 3px 0 rgba(0,0,0,.16);-webkit-box-shadow:0 2px 3px 0 rgba(0,0,0,.16);box-shadow:0 2px 3px 0 rgba(0,0,0,.16);z-index:999999;padding:10px 0;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box}.jquery-script-center{max-width:960px;margin:0 auto}.jquery-script-center ul{width:212px;float:left;line-height:45px;margin:0;padding:0;list-style:none}.jquery-script-center a{text-decoration:none}.jquery-script-ads{max-width:728px;height:90px;float:right}.jquery-script-clear{clear:both;height:0}#carbonads{display:block;overflow:hidden;max-width:728px;position:relative;font-size:22px;box-sizing:content-box}#carbonads>span{display:block}#carbonads a{color:#4078c0;text-decoration:none}#carbonads a:hover{color:#3664a3}.carbon-wrap{display:flex;align-items:center}.carbon-img{display:block;margin:0;line-height:1}.carbon-img img{display:block;height:90px;width:auto}.carbon-text{display:block;padding:0 1em;line-height:1.35;text-align:left}.carbon-poweredby{display:block;position:absolute;bottom:0;right:0;padding:6px 10px;text-align:center;text-transform:uppercase;letter-spacing:.5px;font-weight:600;font-size:8px;border-top-left-radius:4px;line-height:1;color:#aaa!important}@media only screen and (min-width:320px) and (max-width:759px){.carbon-text{font-size:14px}}@media only screen and (max-width:1023px){.jquery-script-ads{display:none}} 

</style>

</head>
<body style="background-color: #fff;">
  <?php 
  include("header.php");
  include("sidebar.php");
  ?>

<?php 
include("DbConnection.php");

$sql = "SELECT * FROM `news`";
$result = $con->query($sql);
?>
<link rel="stylesheet" href="panel-marquee/css/style.css">
    <link href="jquerysctipttop.css" rel="stylesheet" type="text/css">

    <div class="main" >
      <div class="presenter" style="margin-bottom: 3em;">
        <div class="logoi">
          <hr>
          <h1 id="breaking">Breaking</h1>
          <h1 id="news">News</h1>
          <hr>
        </div>
        <div id="panel" class="container">
          <div class="marquee">
            <ul class="content">
            <?php while ($row = $result->fetch_assoc()) { ?>
              <li><h1><i class="fa fa-newspaper-o" aria-hidden="true"></i><?php echo $row['header'];?></h1></li>
              <?php } ?>
            </ul>
          </div>
      </div>
    </div>
      
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://www.jqueryscript.net/demo/horizontal-panel-marquee/js/horizontal-panel.js"></script>
     <script type="text/javascript">
    $(window).load( function() {
      $('#panel').hpanel({
        duration: 80000
      });
    });
    </script>  
    <?php 
include("DbConnection.php");

$sql = "SELECT * FROM `news`";
$result = $con->query($sql);
?>   
<?php
    while ($rs = $result->fetch_assoc()) {
        $date = $rs['edit_date'];
        $currentDate = date("Y-m-d");

        if ($date === $currentDate) {
            ?>
   

 <div class="wrapper" style="margin-top: auto; margin-bottom: auto;">

<div class="background-container">
    <div class="bg-1"></div>
    <div class="bg-2"></div>

</div>
<div class="about-container">

    <div class="image-container">
    <?php
     echo '  
                           
     <img src="data:image/jpeg;base64,'.base64_encode($rs['img'] ).'" height="100px" width="100px" class="img-thumnail" />  

'; 
    ?>

        
    </div>
    
    <div class="text-container">
        <h3><?php echo $rs['header'];?></h3>
        <p style="font-size: 15px; margin-top: 1.5em;">
        <?php echo $rs['information'];?>
      </p>
      <p style="margin-top: 1em;">Location: <?php echo $rs['location'];?></p>
      <?php 
      $ok=$rs['extra'];
      if($ok>0){
        ?>
        <p style="margin-top: 1em;"><a href='<?php echo $rs['extra'];?>' target="_blank"><i class="fas fa-link"></i> <?php echo $rs['link_description'];?></a></p>
     <?php } ?>
    
      
    </div>
    
</div>
</div>
<?php } ?>
<?php } ?>
<h2 style="margin-top: 5rem;"> <marquee width="100%" direction="left" height="50px"> <i class="fa-solid fa-user-secret" style="margin-right: 0.5em; margin-left: 0.5em;"></i>  Note: News will be Uploaded at 7:00 a.m.   <i class="fa-solid fa-user-secret" style="margin-right: 0.5em; margin-left: 0.5em;"></i>  Note: If there is any kind of news, please send it along with the photo.    <i class="fa fa-phone" aria-hidden="true" style="margin-left: 0.5em; margin-right:0.5em"></i> Whatsapp No.: +91 1234567890     <i class="fa fa-envelope" aria-hidden="true" style="margin-right: 0.5em; margin-left: 0.5em;"></i> Email: news@heavanspacez.com </marquee> </h2>

  <?php 
  include("footer.php");
  ?>
</body>
</html>