
<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <!-- <title>HeavanSpacez Others</title> -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
   <link rel="stylesheet" href="<?= base_url("css/style.css");?>"> 
   
</head>

<body>

<header class="header">
   
   <section class="flex">

      <a href="<?php echo base_url('index.php/Controller/dashboard')?>" class="logo"><img src="<?= base_url("images/HS.png");?>" style="  height: 50px;"> </a>

      <form action="<?php echo base_url().'index.php/Controller/searchFiles'?>" method="post" class="search-form">
         <input type="text" name="search_box" required placeholder="Search Document..." maxlength="100" style="width: 100%;
                                                                                                               font-size: 1.8rem;
                                                                                                               color: var(--black);
                                                                                                               background: none;
                                                                                                               padding: 0;
                                                                                                               box-sizing: border-box;
                                                                                                               outline: none;
                                                                                                               border: none;
                                                                                                               text-decoration: none;
         ">
         <button type="submit" name="submit" id="submit" class="fas fa-search"></button>
      </form>

      <div class="icons">
         <div id="search-btn" class="fas fa-search"></div>
         <a href="<?= base_url().'index.php/LoginController/logout'?>"><div id="user-btn" class="fa-solid fa-power-off"></div></a>
      </div>

   </section>

</header>   
<script src="js/script.js"></script>
</body>

</html>