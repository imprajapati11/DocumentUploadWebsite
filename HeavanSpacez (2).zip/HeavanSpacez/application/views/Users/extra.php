<?php $userID=$this->session->userdata('user_id');?>
 
 <!DOCTYPE html>  
 <html>  
      <head>  
             
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />   -->
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
           <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">


           <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>HeavanSpacez Edit Image</title>

      <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
      <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
      <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
      <link rel="stylesheet" href="<?= base_url('css/style.css');?>">

      
      <style>
        .row{
          display: -ms-flexbox;
          display: flex;
          -ms-flex-wrap: wrap;
          flex-wrap: wrap;
          margin-right: -15px;
          margin-left: -8em;
          margin-top: 10em;
        }
.img-account-profile {
    height: 10rem;
}
.rounded-circle {
    border-radius: 50% !important;
}
.card {
    box-shadow: 0 0.15rem 1.75rem 0 rgb(33 40 50 / 15%);
}
.card .card-header {
    font-weight: 500;
}
.card-header:first-child {
    border-radius: 0.35rem 0.35rem 0 0;
    font-size: 2em;
}
.card-header {
    padding: 1rem 1.35rem;
    margin-bottom: 0;
    background-color: rgba(33, 40, 50, 0.03);
    border-bottom: 1px solid rgba(33, 40, 50, 0.125);
}
input[type=text],textarea, select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
  font-size: 1.5em;
}
.col-25 {
  float: left;
  width: 15%;
  margin-top: 6px;
}
.row-card{
          display: -ms-flexbox;
          display: flex;
          -ms-flex-wrap: wrap;
          flex-wrap: wrap;
          /* margin-right: -15px; */
          margin-left: -8em;
          margin-top: 1em;
        }
.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

.row-card:after {
  content: "";
  display: table;
  clear: both;
}
.container {
    width: 90%;
    margin-right: -2em;
    border-radius: 5px;
    /* background-color: #f2f2f2; */
    padding: 5px;
    margin-top: -2em;

    /* margin-right: -15em; */
    /* margin-top: -12.5em; */
    /* margin-top: 150px; */
}
input[type=submit] {
    
    background-color: var(--main-color);
    color: white;
    width: 95%;
    font-size: 2em;
    margin-top: 5px;
    /* margin-left: 170px; */
    /* margin-right: 525px; */
    padding: 15px 25px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
  }
  
  input[type=submit]:hover {
      background-color: var(--black);
  }
label {
  padding: 12px 12px 12px 15px;
  display: inline-block;
  font-size: 15px;
}
.form-control, .dataTable-input {
    /* display: block;
    width: 100%;
    padding: 0.875rem 1.125rem;
    font-size: 0.875rem;
    font-weight: 400;
    line-height: 1;
    color: #69707a;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #c5ccd6;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    border-radius: 0.35rem;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out; */
}
</style>

      </head>  
      <body style="background-color: #fff;">  
          <?php 
          include("header.php");?>
          <?php 
          include("sidebar.php");
          ?>
  <div class="container-xl px-4 mt-4">
           <hr class="mt-0 mb-4">
    <div class="row">
        <div class="col-xl-4">
            <!-- Profile picture card-->
            <form action="<?php echo base_url('index.php/My/insert_image')?>" method="post" enctype="multipart/form-data" style="background-color: #f2f2f2;">
            <div class="card mb-4 mb-xl-0">
                <div class="card-header">Profile Picture</div>
                <div class="card-body text-center">
                    <!-- Profile picture image-->
                    <?php  
                        $connect = mysqli_connect("localhost", "root", "", "heavanspacez");  
                        $query = "SELECT * FROM img WHERE user_id='$userID'";  
                        $result = mysqli_query($connect, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_array($result)) {
                                echo '<img src="data:image/jpeg;base64,'.base64_encode($row['img']).'" height="100px" width="100px" class="img-thumbnail" />';
                            }
                        } else {
                            // Display default image when no image is available
                            echo '<img src='.base_url("images/DefaultPic.jpg").' height="100px" width="100px" class="img-thumbnail" />';
                        }
                    ?>
                    <input type="file" name="image" id="image" style=" width: 75%;
                                                                    padding: 15px;
                                                                    margin-left: 5em;
                                                                    font-size: 1.5em;"
                                                                    />  
                    <!-- Profile picture help block-->
                    <div class="small font-italic text-muted mb-4" style="font-size: 1.2em;">JPG or PNG no larger than 5 MB</div>
                    <!-- Profile picture upload button-->
                    <input type="submit" name="insert" id="insert" value="Upload Image">
                   <div style="margin-top: 10em;">
               <?php if ($this->session->flashdata('updateMessage')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-top: 1em; font-size: 2em;">
                  <?php echo $this->session->flashdata('updateMessage'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                </div>
               <?php endif; ?>
               <?php if ($this->session->flashdata('insertMessage')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-top: 1em; font-size: 2em;">
                  <?php echo $this->session->flashdata('insertMessage'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                </div>
               <?php endif; ?>
                   </div>
            </form>
                </div>
            </div>
        </div>
        <div class="col-xl-8">
            <!-- Account details card-->
            <div class="card mb-4">
                <div class="card-header">Account Details</div>
                <div class="card-body">
                <form action="<?php echo base_url('index.php/My/update_profile')?>" method="POST" style="margin-top: 15px;">
    <?php
    $query = $this->db->get_where('users', array('id' => $userID));
    $result = $query->row_array();
    ?>
    <div class="container">
        <div class="row-card">
            <div class="col-25">
                <label for="fname">First Name</label>
            </div>
            <div class="col-75">
                <input class="input100" type="text" name="fname" id="fname" value="<?php echo $result['fname']; ?>">
            </div>
        </div>
        <div class="row-card">
            <div class="col-25">
                <label for="lname">Last Name</label>
            </div>
            <div class="col-75">
                <input class="input100" type="text" name="lname" id="lname" value="<?php echo $result['lname']; ?>">
            </div>
        </div>
        <div class="row-card">
            <div class="col-25">
                <label for="country">Mobile Number</label>
            </div>
            <div class="col-75">
                <input class="input100" type="text" name="phoneno" id="phoneno" value="<?php echo $result['phoneno']; ?>">
            </div>
        </div>
        <div class="row-card">
            <div class="col-25">
                <label for="subject">Email</label>
            </div>
            <div class="col-75">
                <input class="input100" type="text" name="email" id="email" value="<?php echo $result['email']; ?>" readonly>
                <span style="color: #8C2F00;"> *Note: Email Can't Change. </span>
            </div>
        </div>
        <div class="row-card">
            <div class="col-25">
                <label for="subject">City</label>
            </div>
            <div class="col-75">
                <input class="input100" type="text" name="city" id="city" value="<?php echo $result['city']; ?>">
            </div>
        </div>
        <div class="row-card">
            <input type="submit" value="Save changes">
        </div>
    </div>
</form>

                </div>
            </div>
        </div>
    </div>
  </div>
  

    </form>

</div>
           </div>

           <?php 
           include('footer.php');
           ?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>

      </body> 
 </html>  
 <script>  
 $(document).ready(function(){  
      $('#insert').click(function(){  
           var image_name = $('#image').val();  
           if(image_name == '')  
           {  
                alert("Please Select Image");  
                return false;  
           }  
           else  
           {  
                var extension = $('#image').val().split('.').pop().toLowerCase();  
                if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
                {  
                     alert('Invalid Image File');  
                     $('#image').val('');  
                     return false;  
                }  
           }  
      });  
 });  
 </script>