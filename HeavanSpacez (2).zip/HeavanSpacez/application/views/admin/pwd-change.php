<?php 
$userID=$this->session->userdata('user_id');
$isAdmin=$this->session->userdata('isAdmin');

if (!$isAdmin) {
  redirect('index.php/Controller/dashboard');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>HeavanSpacez Password Change</title>
      <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
      <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
      <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

      <style>
* {
  box-sizing: border-box;
}

input[type=password],textarea, select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
  font-size: 1.5em;
}

label {
  padding: 12px 12px 12px 15px;
  display: inline-block;
  font-size: 15px;
}

input[type=submit] {
    
  background-color: var(--main-color);
  color: white;
  margin-top: 5px;
  margin-left: 170px;
  /* margin-right: 525px; */
  padding: 15px 25px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit]:hover {
    background-color: var(--black);
}

.container {
    width: 100%;
    margin-left: -50px;
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
    margin-top: 150px;
}

.col-25 {
  float: left;
  width: 15%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 85%;
  margin-top: 6px;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}

@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>

</head>
<body style="background-color: #fff;">


  <?php 
    include("admin-header.php");
  ?>
  <?php
      include('admin-sidebar.php');
    
  ?>
  <div class="container">
  <span style="font-size: 25px;"><i class="fa fa-key" aria-hidden="true"></i>   <u style="text-decoration: underline;">Edit your Password</u></span>
    <form action="" method="POST" style="margin-top: 15px;">
      <div class="row">
        <div class="col-25">
          <label for="password">Current Password</label>
        </div>
        <div class="col-75">
        <input class="input100" type="password" name="password" id="password" placeholder="Enter you Current Password">
        </div>
      </div>
      <div class="row">
        <div class="col-25">
          <label for="newpassword">New Password</label>
        </div>
        <div class="col-75">
          <input class="input100" type="password" name="newpassword" id="newpassword" placeholder="Enter New Password">
        </div>
      </div>
      <div class="row">
        <div class="col-25">
          <label for="confirmnewpassword">Confirm Password</label>
        </div>
        <div class="col-75">
          <input class="input100" type="password" name="confirmnewpassword" id="confirmnewpassword" placeholder="Enter Confirm New-Password">
        </div>
      </div>
      <div class="row">
        <input type="submit" value="Update">
      </div>    
  <p style="font-size: 20px; text-align: center; margin-top: 10px;">
    <?php

    include("DbConnection.php");

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $userID = $_SESSION['user_id'];
        $password = $_POST['password'];
        $newpassword = $_POST['newpassword'];
        $confirmnewpassword = $_POST['confirmnewpassword'];
        $password=md5($password);
        $sql="select password from users where password='$password' AND id='$userID'";

        $res=mysqli_query($con,$sql);
        //Current Password Check Condition
        if (mysqli_num_rows($res) > 0) {
          
          $row = mysqli_fetch_assoc($res);
          //Current Password True
          if($password==isset($row['password']))
          {
            //New Password And Confirm Newpassword Check
            if($newpassword === $confirmnewpassword){

                $newpassword=md5($newpassword);
                $sql = "UPDATE users SET password='$newpassword' WHERE id='$userID'";
                    //Condition True
                    if ($con->query($sql) === TRUE) {
                      $this->session->set_flashdata('form_data',$_POST);
                      $this->session->set_flashdata('message','Sucesscefully Password Change :)');
                      redirect(base_url('index.php/Settings/changepassword'));
                    
                    } else {
                        echo "Error ";
                    }
            //New Password And Confirm Newpassword Error
            }else{
              $this->session->set_flashdata('form_data', $_POST);
              $this->session->set_flashdata('errorMessage', 'Passwords Must Match :)');
              redirect(base_url('index.php/Settings/changepassword'));
                }
          }
        //Current Password Error
        }else{
          $this->session->set_flashdata('form_data', $_POST);
          $this->session->set_flashdata('currentMessage', 'Incorrect Current Password :)');
          redirect(base_url('index.php/Settings/changepassword'));

            }
      }
    ?>


              <?php if ($this->session->flashdata('message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-top: 1em; font-size: 1.2em; width: 25%; margin-left: 12.8em;  ">
                  <?php echo $this->session->flashdata('message'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                </div>
               <?php endif; ?>

               <?php if ($this->session->flashdata('errorMessage')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert" style="margin-top: 1em; font-size: 1.2em; width: 25%; margin-left: 12.8em;  ">
                  <?php echo $this->session->flashdata('errorMessage'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                </div>
               <?php endif; ?>

               <?php if ($this->session->flashdata('currentMessage')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert" style="margin-top: 1em; font-size: 1.2em; width: 25%; margin-left: 12.8em;  ">
                  <?php echo $this->session->flashdata('currentMessage'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                </div>
               <?php endif; ?>
  </p>
  </form>

  </div>
            
  <?php include('footer.php');?>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    
</body>
</html>

<script>  
 $(document).ready(function(){  
      $('#insert').click(function(){  
           var image_name = $('#image').val();  
           if(image_name == '')  
           {  
                alert("Please Select Image");  
                return false;  
           }  
           else  
           {  
                var extension = $('#image').val().split('.').pop().toLowerCase();  
                if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
                {  
                     alert('Invalid Image File');  
                     $('#image').val('');  
                     return false;  
                }  
           }  
      });  
 });  
 </script>