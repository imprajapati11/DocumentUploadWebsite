<?php 
$userID=$this->session->userdata('user_id');
$isAdmin=$this->session->userdata('isAdmin');

if (!$isAdmin) {
  redirect('index.php/Controller/dashboard');
}
?>

<?php $userID=$this->session->userdata('user_id');?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>HeavanSpacez Update Details</title>
      
      <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
      <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
      <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

      <style>
* {
  box-sizing: border-box;
}

input[type=text],textarea, select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
  font-size: 1.5em;
}

label {
  padding: 12px 12px 12px 15px;
  display: inline-block;
  font-size: 15px;
}

input[type=submit] {
    
  background-color: var(--main-color);
  color: white;
  margin-top: 5px;
  margin-left: 170px;
  /* margin-right: 525px; */
  padding: 15px 25px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit]:hover {
    background-color: var(--black);
}

.container {
    width: 100%;
    margin-left: -50px;
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
    margin-top: 150px;
}

.col-25 {
  float: left;
  width: 15%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 85%;
  margin-top: 6px;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}

@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>


</head>
<body style="background-color: #fff;">


<?php 
include("admin-header.php");
?>
 <?php 
    include('admin-sidebar.php');
?> 
<div class="container">
<span style="font-size: 25px;"><i class="fas fa-user-edit"></i>   <u style="text-decoration: underline;">Edit Your Profile</u></span>
  <form action="" method="POST" style="margin-top: 15px;">

    <div class="row">
      <div class="col-25">
        <label for="fname">First Name</label>
      </div>
      <div class="col-75">
      <input class="input100" type="text" name="fname" id="fname" value="<?php echo $result['fname']; ?>">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Last Name</label>
      </div>
      <div class="col-75">
        <input class="input100" type="text" name="lname" id="lname" value="<?php echo $result['lname']; ?>">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Mobile Number</label>
      </div>
      <div class="col-75">
        <input class="input100" type="text" name="phoneno" id="phoneno" value="<?php echo $result['phoneno']; ?>">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="subject">Email</label>
      </div>
      <div class="col-75">
            <input class="input100" type="text" name="email" id="email" value="<?php echo $result['email']; ?>" readonly>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="subject">City</label>
      </div>
      <div class="col-75">
            <input class="input100" type="text" name="city" id="city" value="<?php echo $result['city']; ?>">
      </div>
    </div>

    <div class="row">
      <input type="submit" value="Update">
    </div>

    <div class="row">
      <span style="margin-top: 5px;">
            <?php if ($this->session->flashdata('updateMsg')): ?>
              <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-left: 10px; font-size: 1.5em; margin-left: 11.4em;" >
                <?php echo $this->session->flashdata('updateMsg'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
              </div>
            <?php endif; ?>
      </span>
    </div>

      
<p style="font-size: 20px; text-align: center; margin-top: 10px;">
    <?php

    include("DbConnection.php");

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $phoneno = $_POST['phoneno'];
    $email = $_POST['email'];
    $city = $_POST['city'];
    $date = date('Y-m-d H:i:s');


    $stmt = $con->prepare("UPDATE users SET fname = ?, lname = ?, phoneno = ?, email = ?, city = ?, update_date = ? WHERE id = ?");
    $stmt->bind_param("ssssssi", $fname, $lname, $phoneno, $email, $city,$date, $userID);
    $stmt->execute();
    $stmt->close();

    header('update-profile.php');

    $this->session->set_flashdata('form_data',$_POST);
    $this->session->set_flashdata('updateMsg','Information updated successfully.');
    redirect(base_url('index.php/Settings/basicdetails'));
    }
    ?>

  </p>
  </form>

</div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

       
<?php include('footer.php');?>
   
</body>
</html>