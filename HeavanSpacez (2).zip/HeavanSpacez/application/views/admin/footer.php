<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="<?= base_url('fonts/icomoon/style.css');?>">
 

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<body>



<footer class="footer" style="
    background-color: var(--white);
    border-top: var(--border);
    position: fixed;
    margin-bottom: -0.7em;
    left: 0;
    right: 0;
    /* text-align: center; */
    font-size: 2rem;
    padding: 2rem 2.2rem; 
    color: var(--black);
   
    z-index: 1000;
">


<p style="text-align: center; margin-left: 150px;">Copyright © 2023 <a href="https://www.linkedin.com/in/imprajapati11/?originalSubdomain=in" target="_blank" style="color: midnightblue;">HeavanSpacez.com</a> | All Rights Reserved.
    
    <a href="https://www.instagram.com/_imprajapati11_/" target="_blank" style="margin-left: 50px;"><i class="fa-brands fa-instagram" style="color: midnightblue; color: midnightblue;"></i></a>
    <a href="https://m.facebook.com/profile.php?id=100007425617660" target="_blank"><i class="fa-brands fa-facebook-f" style="margin-left: 10px; color: midnightblue;"></i></a>
    <a href="https://github.com/imprajapati" target="_blank"><i class="fa-brands fa-github" style="margin-left: 10px; color: midnightblue;"></i></a>
    <a href="https://www.linkedin.com/in/imprajapati11/?originalSubdomain=in" target="_blank" style="margin-left: 10px;"><i class="fa fa-linkedin" aria-hidden="true" style="color: midnightblue;"></i></a>
    
</p>
         


</footer>
<script src="<?= base_url('js/script.js');?>"></script>
</body>
</html>