<?php 
$userID=$this->session->userdata('user_id');
$isAdmin=$this->session->userdata('isAdmin');

if (!$isAdmin) {
  redirect('index.php/Controller/dashboard');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>HeavanSpacez Document Search</title>

      <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
      <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
      <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
      <link rel="stylesheet" href="<?= base_url('assets/css/fontawesome.css');?>">
      <link rel="stylesheet" href="<?= base_url('assets/css/animated.css');?>">
      <link rel="stylesheet" href="<?= base_url('assets/css/owl.css');?>">

    <style>
table {
  margin-top: auto;
  padding: auto;
  border: 1px solid #ccc;
  border-collapse: collapse;
  width: 100%;
  table-layout: fixed;
  border-radius: 10px;
 margin-left: -50px;
  text-align: center;
  margin-bottom: 150px;
}


table caption {
  font-size: 2px;
  margin: .5em 0 .75em;
}

table tr {
  background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;
  font-size: 15px;;
}

table th,
table td {
  padding: .625em;
  text-align: center;
}

table th {
  font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;
}

@media screen and (max-width: 600px) {
  table {
    border: 0;
  }

  table caption {
    font-size: 1.3em;
  }
  
  table thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  
  table tr {
    border-bottom: 3px solid #ddd;
    display: block;
    margin-bottom: .625em;
  }
  
  table td {
    border-bottom: 1px solid #ddd;
    display: block;
    font-size: .8em;
    text-align: right;
  }
  
  table td::before {
    content: attr(data-label);
    float: left;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  table td:last-child {
    border-bottom: 0;
  }
}

body {
  font-family: "Open Sans", sans-serif;
  line-height: 1.25;
}
</style>
    </head>
<body style="background-color: #fff;">


<?php include('admin-header.php');?>
   <?php 
   include('admin-sidebar.php');

?> 

<?php 
$search_box=$_POST['search_box'];
?>
<h3 style="margin-top: 140px; text-align: center; font-size: 20px; margin-bottom: 25px;"><u style="text-decoration: underline;"> View <?php echo $search_box ?> Related Document</u></h3>
<table>
    <tr>
        <!-- <th>User Name</th> -->
        <th>Users Name</th>
        <th>Email</th>
        <th>Phone Number</th>
        <th>File Name</th>
        <th>Uplaod Date</th>
        <th>Action</th>
    </tr>
    
<?php if ($results) : ?>   
   
        <?php foreach ($results as $result) : ?>
          
          <tr>
            <td><?php echo $result['fname'];?></td>
            <td><?php echo $result['email'];?></td>
            <td><?php echo $result['phoneno'];?></td>
            <td><?php echo $result['file_name']; ?></td>
            <td><?php echo $result['upload_date']; ?></td>
            <td><a target="_blank" href="http://localhost/heavanspacez/images/uploaded/<?php echo $result['file_path']; ?>"><i class="fa-solid fa-eye"></i></a>
        </tr>
        <?php endforeach; ?>   
<?php else : ?>
  <tr>
  
   <td colspan="6">No results found.</td>
  
  </tr>
 
<?php endif; ?>
</table>

<?php 
include("footer.php");
?>
</body>
</html>
