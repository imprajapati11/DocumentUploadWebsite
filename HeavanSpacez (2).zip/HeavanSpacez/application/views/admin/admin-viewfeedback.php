<?php 
$userID=$this->session->userdata('user_id');
$isAdmin=$this->session->userdata('isAdmin');

if (!$isAdmin) {
  redirect('index.php/Controller/dashboard');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>HeavanSpacez Feedback List</title>
      <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
      <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
      <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
      <link rel="stylesheet" href="<?= base_url('assets/css/fontawesome.css');?>">
      <link rel="stylesheet" href="<?= base_url('assets/css/animated.css');?>">
      <link rel="stylesheet" href="<?= base_url('assets/css/owl.css');?>">
    <style>
table {
    margin-top: auto;

    padding: auto;
  border: 1px solid #ccc;
  border-collapse: collapse;
  width: 100%;
  table-layout: fixed;
  border-radius: 10px;
 margin-left: -50px;
  text-align: center;
  margin-bottom: 90px;
}


table caption {
  font-size: 2px;
  margin: .5em 0 .75em;
}

table tr {
  background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;
  font-size: 15px;;
}

table th,
table td {
  padding: .625em;
  text-align: center;
  overflow: hidden;
    text-overflow: ellipsis;
    /* white-space: nowrap; */
}

table th {
  font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;
}

@media screen and (max-width: 600px) {
  table {
    border: 0;
  }

  table caption {
    font-size: 1.3em;
  }
  
  table thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  
  table tr {
    border-bottom: 3px solid #ddd;
    display: block;
    margin-bottom: .625em;
  }
  
  table td {
    border-bottom: 1px solid #ddd;
    display: block;
    font-size: .8em;
    text-align: right;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  
  table td::before {
    content: attr(data-label);
    float: left;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  table td:last-child {
    border-bottom: 0;
  }
}

body {
  font-family: "Open Sans", sans-serif;
  line-height: 1.25;
}
</style>
    </head>
<body style="background-color: #fff;">


<?php include('admin-header.php');?>
   <?php include('admin-sidebar.php');?> 

   <?php 
include("DbConnection.php");

$sql = "SELECT * FROM `feedback`";
$result = $con->query($sql);
?>
<h3 style="margin-top: 5.5em; text-align: center; font-size: 20px; margin-bottom: 25px;"><u style="text-decoration: underline;"> Feedback List</u></h3>
<table>
    <tr>
        <th>No.</th>
        <th>User Firstname</th>
        <th>Phone Number</th>
        <th>Email</th>
        <th>Feedback Date</th>
        <th>Feedback</th>
        <!-- <th>Action</th> -->
    </tr>
    <?php $i=1; while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $i; $i++;?>
            <td><?php echo $row['fname'];?></td>
            <td><?php echo $row['phoneno']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['feedback_date']; ?></td>
            <td><?php echo $row['msg']; ?></td>
            <!-- <td><a href="#"><i class="fa-solid fa-trash-can"></i></a> -->
            
        </tr>
    <?php } ?>
</table>

<?php 
$con -> close();
?>

<?php 
include("DbConnection.php");

$id = isset($_GET['id']) ? $_GET['id'] : null;

if ($id === null) {
//     // echo "Document ID is missing";
//     exit;
 }else{
    $delete= "DELETE FROM result WHERE id='$id' AND user_id='$userID'";

if(mysqli_query($con,$delete)){
  echo '<script>alert("Delete File")</script>';
}else{
    echo '<script>alert("Error")</script>';
}
 }
?>


<?php 
include("footer.php");
?>
</body>
</html>
