<?php 
$userID=$this->session->userdata('user_id');
$isAdmin=$this->session->userdata('isAdmin');

if (!$isAdmin) {
  redirect('index.php/Controller/dashboard');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>HeavanSpacez Add User</title>
   <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
   <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
   <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script>
      function verifyForm() {
        var fname = document.getElementById("fname").value;
        var lname = document.getElementById("lname").value;
        var phoneno = document.getElementById("phoneno").value;
        var email = document.getElementById("email").value;
        var password = document.getElementById("password").value;
        var cpassword = document.getElementById("cpassword").value;
        
        //check empty password field
        if(fname == "") {
          document.getElementById("ferror").innerHTML = "**Fill the Firstname please!";
          return false;
        }
        var namePattern = /^[a-zA-Z ]+$/;
        if(!namePattern.test(fname)){
          document.getElementById("ferror").innerHTML = "*First name must contain only alphabets.";
        }
        var lnamePattern = /^[a-zA-Z ]+$/;
        if(!lnamePattern.test(lname)){
          document.getElementById("lerror").innerHTML = "*Last name must contain only alphabets.";
        }
        if(lname == ""){phoneno
          document.getElementById("lerror").innerHTML = "**Fill the Lastname please!";
          return false;
        }
        if(phoneno == ""){
          document.getElementById("phonenoerror").innerHTML = "**Fill the Phone Number please!";
          return false;
        }
        var regex = /^\d{10}$/;
        if(!regex.test(phoneno)){
          document.getElementById("phonenoerror").innerHTML = "**Invalid phone number format."
        }
        if(email == ""){
          document.getElementById("emailerror").innerHTML = "**Fill the Email please!";
          return false;
        }
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
          document.getElementById("emailerror").innerHTML = "**Invalid email format.";
          return false;
        }

        if(password == ""){
          document.getElementById("pwderror").innerHTML = "**Fill the Password please!";
          return false;
        }
        if(cpassword == ""){
          document.getElementById("cpwderror").innerHTML = "**Fill the Password please!";
          return false;
        }
        if (password !== cpassword) {
          document.getElementById("cpwderror").innerHTML = "*Passwords do not match.";
          return false;
        }

      }
</script>
<style>
* {
  box-sizing: border-box;
}

input[type=password],input[type=text],select,textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
  font-size: 1.5em;
}

label {
  padding: 12px 12px 12px 15px;
  display: inline-block;
  font-size: 15px;
}

input[type=submit] {
    
  background-color: var(--main-color);
  color: white;
  margin-top: 5px;
  margin-left: 170px;
  /* margin-right: 525px; */
  padding: 15px 25px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit]:hover {
    background-color: var(--black);
}

select{
  background-color: #fff;
}

.container-feed {
    width: 100%;
    margin-left: -50px;
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
    margin-top: 150px;
    margin-bottom: 110px;
}

.col-25 {
  float: left;
  width: 15%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 80%;
  margin-top: 6px;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}

@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>


</head>
<?php include('admin-header.php');?>
<?php include('admin-sidebar.php');?>

<body style="background-color: #fff;">



<div class="container-feed">
<span style="font-size: 25px;"><u style="text-decoration: underline;"><i class="fa fa-user-plus" aria-hidden="true"></i>Add User</u></span>
  <form action="" method="POST" style="margin-top: 10px;" onsubmit ="return verifyForm()">

    <div class="row">
      <div class="col-25">
        <label for="fname">First Name</label>
      </div>
      <div class="col-75">
      <input class="input100" type="text" name="fname" id="fname">
      <span id="fnameError" style="color: #8C2F00;"></span>
      <span id = "ferror" style="color:red; font-size:15px;"> </span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Last Name</label>
      </div>
      <div class="col-75">
        <input class="input100" type="text" name="lname" id="lname" >
        <span id = "lerror" style="color:red; font-size:15px;"> </span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Mobile Number</label>
      </div>
      <div class="col-75">
        <input class="input100" type="text" name="phoneno" id="phoneno">
        <span id = "phonenoerror" style="color:red; font-size:15px;"> </span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="subject">Email</label>
      </div>
      <div class="col-75">
            <input class="input100" type="text" name="email" id="email">
            <span id = "emailerror" style="color:red; font-size:15px;"> </span>
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="subject">City</label>
      </div>
      <div class="col-75">
              <div ng-app="myapp" style="font-size: 1.5em;">
                  <select name="country" id="country">
                        <option value="">Select country</option>
                        <?php foreach ($countries as $country) : ?>
                            <option value="<?php echo $country['id']; ?>"><?php echo $country['name']; ?></option>
                        <?php endforeach; ?>
                    </select>

                    <select name="state" id="state" style="margin-top: 6px;">
                        <option value="">Select state</option>
                    </select>

                    <select name="city" id="city" style="margin-top: 6px;">
                        <option value="">Select city</option>
                    </select>
              </div>
        </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="subject">Password</label>
      </div>
      <div class="col-75">
            <input class="input100" type="password" name="password" id="password">
            <span id = "pwderror" style="color:red; font-size:15px;"> </span>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="subject">Confirm Password</label>
      </div>
      <div class="col-75">
            <input class="input100" type="password" name="cpassword" id="cpassword">
            <span id = "cpwderror" style="color:red; font-size:15px;"> </span>
      </div>
    </div> 
    

    <div class="row">
      
      <input type="submit" name="submit" id="submit" value="Add">

    </div>
    <div class="row">
      <span style="margin-top: 5px;">
            <?php if ($this->session->flashdata('errorUser')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert" style="margin-left: 10px; font-size: 1.5em; margin-left: 11.4em;">
                  <?php echo $this->session->flashdata('errorUser'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                </div>
            <?php endif; ?>
            <?php if ($this->session->flashdata('addUser')): ?>
              <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-left: 10px; font-size: 1.5em; margin-left: 11.4em;" >
                <?php echo $this->session->flashdata('addUser'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
              </div>
            <?php endif; ?>
      </span>
    </div>
  </form>

</div>

 <?php 
    include("DbConnection.php");


    if(isset($_POST['submit'])){
      $fname=$_POST['fname']; 
      $lname=$_POST['lname'];
      $phoneno=$_POST['phoneno'];
      $email=$_POST['email'];
      $city=$_POST['city'];
      $password=$_POST['password'];
      $registrationDate = date('Y-m-d H:i:s');

      $sql="select * from users where email='$email'";

      $res=mysqli_query($con,$sql);
      if (mysqli_num_rows($res) > 0) {
        $row = mysqli_fetch_assoc($res);
          if($email==isset($row['email']))
          {
            $this->session->set_flashdata('form_data',$_POST);
            $this->session->set_flashdata('errorUser','Email Already Exist');
            redirect(base_url('index.php/AdminRedirect/adduser'));
            // echo '<script>alert("Email Already Exist!!")</script>';
          }
      }
      else{
          $password=md5($password);
          $sql="INSERT INTO `users` (fname,lname,phoneno,email,city, password, registration_date) VALUES ('$fname','$lname','$phoneno','$email','$city', '$password','$registrationDate')";

          if($con->query($sql)===true){
            $this->session->set_flashdata('form_data',$_POST);
            $this->session->set_flashdata('addUser','User Successfully Added');
            redirect(base_url('index.php/AdminRedirect/adduser'));
              // echo '<script>alert("User Successfully Added")</script>';
          }else{
              echo '<script>alert("Some Error!!")</script>';
          }
      }
    }   
    ?> 

    <!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script> -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<?php 
include('footer.php');
?>






</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $("#country").change(function() {
            var countryId = $(this).val();
            $.ajax({
                url: "<?php echo base_url('index.php/LocationController/getStates'); ?>",
                type: "POST",
                data: {
                    country_id: countryId
                },
                dataType: "json",
                success: function(data) {
                    var options = '<option value="">Select state</option>';
                    data.forEach(function(state) {
                        options += '<option value="' + state.id + '">' + state.name + '</option>';
                    });
                    $("#state").html(options);
                    $("#city").html('<option value="">Select city</option>');
                }
            });
        });

        $("#state").change(function() {
            var stateId = $(this).val();
            $.ajax({
                url: "<?php echo base_url('index.php/LocationController/getCities'); ?>",
                type: "POST",
                data: {
                    state_id: stateId
                },
                dataType: "json",
                success: function(data) {
                    var options = '<option value="">Select city</option>';
                    data.forEach(function(city) {
                        options += '<option value="' + city.name + '">' + city.name + '</option>';
                    });
                    $("#city").html(options);
                }
            });
        });
    });
</script>