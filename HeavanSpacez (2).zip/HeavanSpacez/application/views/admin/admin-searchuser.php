<?php 
$userID=$this->session->userdata('user_id');
$isAdmin=$this->session->userdata('isAdmin');

if (!$isAdmin) {
  redirect('index.php/Controller/dashboard');
}
?><?php 
$userID=$this->session->userdata('user_id');
$isAdmin=$this->session->userdata('isAdmin');

if (!$isAdmin) {
  redirect('index.php/Controller/dashboard');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>HeavanSpacez Search User</title>
      <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
      <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
      <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
      <link rel="stylesheet" href="<?= base_url('assets/css/fontawesome.css');?>">
      <link rel="stylesheet" href="<?= base_url('assets/css/animated.css');?>">
      <link rel="stylesheet" href="<?= base_url('assets/css/owl.css');?>">
    <style>
table {
    margin-top: auto;

    padding: auto;
  border: 1px solid #ccc;
  border-collapse: collapse;
  width: 100%;
  table-layout: fixed;
  border-radius: 10px;
 margin-left: -50px;
  text-align: center;
  margin-bottom: 90px;
}

table caption {
  font-size: 2px;
  margin: .5em 0 .75em;
}

table tr {
  background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;
  font-size: 15px;;
}

table th,
table td {
  padding: .625em;
  text-align: center;
}

table th {
  font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;
}

@media screen and (max-width: 600px) {
  table {
    border: 0;
  }

  table caption {
    font-size: 1.3em;
  }
  
  table thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  
  table tr {
    border-bottom: 3px solid #ddd;
    display: block;
    margin-bottom: .625em;
  }
  
  table td {
    border-bottom: 1px solid #ddd;
    display: block;
    font-size: .8em;
    text-align: right;
  }
  
  table td::before {
    content: attr(data-label);
    float: left;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  table td:last-child {
    border-bottom: 0;
  }
}

body {
  font-family: "Open Sans", sans-serif;
  line-height: 1.25;
}
</style>
    </head>
<body style="background-color: #fff;">


<?php include('admin-header.php');?>
   <?php include('admin-sidebar.php');?> 
  

   
<h3 style="padding-top: 120px; text-align: center; font-size: 20px;"><u style="text-decoration: underline;"> Find User</u></h3>

<section class="flex" style="margin-top: 10px;">
      <form action="admin-searchuser.php" method="post" class="search-form" 
      style="    width: 50rem;
      border-radius: 0.5rem;
      background-color: var(--light-bg);
      padding: 1.5rem 2rem;
      display: flex;
      gap: 2rem;
      margin-left: -90px;">
         <input type="text" name="search_box" style="width: 100%;
    font-size: 1.8rem;
    color: var(--black);
    background: none;" required placeholder="Find User by Name & Email" maxlength="100">
         <button type="submit" name="submit" id="submit" class="fas fa-search" style="background: none;
    font-size: 2rem;
    cursor: pointer;
    color: var(--black);"></button>
      </form>
   </section>

<table>
    <tr>
        <th>User Firstname</th>
        <th>User Lastname</th>
        <th>Phone Number</th>
        <th>Email</th>
        <th>Registration Date</th>
        <th>Update Profile Date</th>
        <!-- <th>Action</th> -->
    </tr>
    <?php
    
    include("DbConnection.php");
    
    if(isset($_REQUEST['submit'])){
        $name=$_POST['search_box'];
        $sql=" SELECT * FROM users WHERE fname like '%".$name."%' OR email LIKE '%".$name."%'";
        $q=mysqli_query($con,$sql);
    }
    else{
        $sql="SELECT * FROM users";
        $q=mysqli_query($con,$sql);
    }

    while($row=mysqli_fetch_array($q)){ ?>
        <tr>
            <td><?php echo $row['fname']?></td>
            <td><?php echo $row['lname']; ?></td>
            <td><?php echo $row['phoneno']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['registration_date']; ?></td>
            <td><?php echo $row['update_date']; ?></td>
            <!-- <td><a href="#"><i class="fa-solid fa-trash-can"></i></a> -->
            
        </tr>
    <?php } ?>
</table>

<?php 
$con -> close();
?>

<?php 
include("DbConnection.php");

$id = isset($_GET['id']) ? $_GET['id'] : null;

if ($id === null) {
//     // echo "Document ID is missing";
//     exit;
 }else{
    $delete= "DELETE FROM result WHERE id='$id' AND user_id='$userID'";

if(mysqli_query($con,$delete)){
  echo '<script>alert("Delete File")</script>';
}else{
    echo '<script>alert("Error")</script>';
}
 }
?>


<?php 
include("footer.php");
?>
</body>
</html>
