<?php 
$userID=$this->session->userdata('user_id');
$isAdmin=$this->session->userdata('isAdmin');

if (!$isAdmin) {
  redirect('index.php/Controller/dashboard');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>HeavanSpacez</title>
      <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png')?>">
      <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png')?>">
      <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png')?>">

      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">

   <style>
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
  font-size: 1.5em;
}

label {
  padding: 12px 12px 12px 15px;
  display: inline-block;
  font-size: 15px;
}

input[type=submit] {
    
  background-color: var(--main-color);
  color: white;
  margin-top: 5px;
  margin-left: 185px;
  /* margin-right: 525px; */
  padding: 15px 25px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
  font-size: 1.5em;
}

input[type=submit]:hover {
    background-color: var(--black);
}

.container-feed {
    width: 100%;
    margin-left: -50px;
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
    margin-top: 150px;
    margin-bottom: 110px;
}

.col-25 {
  float: left;
  width: 15%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 85%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>


</head>
<body style="background-color: #fff;">


<?php 
include("admin-header.php");
?>
 <?php
   include('admin-sidebar.php');
?> 
<div class="container-feed">
<span style="font-size: 25px;"><i class="fas fa-user-edit"></i>   <u style="text-decoration: underline;">Edit Your Profile</u></span>
<?php if ($user) : ?>
  <?php $id=$user->id;?>
  <form action="<?php echo site_url('index.php/EditUser/edituser/'.$id)?>" method="POST" style="margin-top: 15px;"> 
    <div class="row">
      <div class="col-25">
        <label for="fname">First Name</label>
      </div>
      <div class="col-75">
      <input class="input100" type="text" name="fname" id="fname" value="<?php echo $user->fname; ?>">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="lname">Last Name</label>
      </div>
      <div class="col-75">
        <input class="input100" type="text" name="lname" id="lname" value="<?php echo $user->lname; ?>">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Mobile Number</label>
      </div>
      <div class="col-75">
        <input class="input100" type="text" name="phoneno" id="phoneno" value="<?php echo $user->phoneno; ?>">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="subject">Email</label>
      </div>
      <div class="col-75">
            <input class="input100" type="text" name="email" id="email" value="<?php echo $user->email; ?>">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="subject">City</label>
      </div>
      <div class="col-75">
            <input class="input100" type="text" name="city" id="city" value="<?php echo $user->city; ?>">
      </div>
    </div>
    <?php endif; ?> 
    <div class="row">
      <input type="submit" value="Update">
    </div>
  </form>

</div>
          
       
<?php include('footer.php');?>
   
</body>
</html>