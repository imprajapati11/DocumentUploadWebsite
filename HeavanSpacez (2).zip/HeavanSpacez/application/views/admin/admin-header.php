<?php 
$userID=$this->session->userdata('user_id');
$isAdmin=$this->session->userdata('isAdmin');

if (!$isAdmin) {
  redirect('index.php/Controller/dashboard');
}
?>
<?php $userID=$this->session->userdata('user_id');?>
<!DOCTYPE html>
<html lang="en">
   <head>
   <link rel="stylesheet" href="<?= base_url('css/style.css');?>"> 
   
   </head>

<body>

<header class="header">
   
   <section class="flex">

      <a href="<?php echo base_url().'index.php/AdminRedirect/admin'?>" class="logo"><img src="<?= base_url('images/HS.png');?>" style="  height: 50px;"> </a>

      <form action="<?php echo base_url().'index.php/AdminRedirect/serach'?>" method="post" class="search-form">
      <input type="text" name="search_box" required placeholder="Search Document..." maxlength="100" style="width: 100%;
                                                                                                               font-size: 1.8rem;
                                                                                                               color: var(--black);
                                                                                                               background: none;
                                                                                                               padding: 0;
                                                                                                               box-sizing: border-box;
                                                                                                               outline: none;
                                                                                                               border: none;
                                                                                                               text-decoration: none;
         ">
         <button type="submit" name="submit" id="submit" class="fas fa-search"></button>
      </form>

      <div class="icons">
         <div id="search-btn" class="fas fa-search"></div>
         <a href="<?= base_url().'index.php/LoginController/logout'?>"><div id="user-btn" class="fa-solid fa-power-off"></div></a>
      </div>

   </section>

</header>   
<script src="<?= base_url('js/script.js');?>"></script>
</body>

</html>