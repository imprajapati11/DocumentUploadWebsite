<?php 
$userID=$this->session->userdata('user_id');
$isAdmin=$this->session->userdata('isAdmin');

if (!$isAdmin) {
  redirect('index.php/Controller/dashboard');
}
?>

<?php $userID=$this->session->userdata('user_id');?>
<!DOCTYPE html>
<html lang="en">
<head>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">  
    <link rel="stylesheet" href="<?= base_url('css/style.css');?>">
    <link rel="stylesheet" href="<?= base_url('css/extracss.css');?>"> 


<style>

    .img-thumbnail {
      padding: .25rem;
      background-color: #fff;
      border: 1px solid #dee2e6;
      border-radius: .25rem;
      max-width: 100%;
      height: auto;
      border-radius: 50%;
    }

    img {
      vertical-align: middle;
      border-style: none;
    }

  .sidenav a, .dropdown-btn {
    padding: 6px 8px 6px 16px;
    text-decoration: none;
    font-size: 18px;
    font-family: 'Times New Roman', Times, serif;
    color: var(--light-color);
    background-color: transparent;
    display: block;
    border: none;
    background: none;
    width: 100%;
    text-align: left;
    cursor: pointer;
    outline: none;
  }
  a:hover, .dropdown-btn:hover {
    color: var(--light-color);
    background-color: transparent;
  }
  .active {
    background-color: transparent;
    
  }
  .dropdown-container {
    display: none;
  width: 100%;
    padding-left: 8px;
  }
  .dropdown-container:hover {
    color: var(--light-color);
    background-color: transparent;
    padding-left: 8px;
  }
  .fa-caret-down {
    float: right;
    padding-right: 8px;
  } 

</style>

</head>

<body>

<div class="side-bar">

   <div id="close-btn">
      <i class="fas fa-times"></i>
   </div>

   <div class="profile">
   <a href="<?php echo base_url().'index.php/Settings/editimg'?>">
        <?php  
          $connect = mysqli_connect("localhost", "root", "", "heavanspacez");  
          $query = "SELECT * FROM img WHERE user_id='$userID'";  
          $result = mysqli_query($connect, $query);

          if (mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_array($result)) {
                  echo '<img src="data:image/jpeg;base64,'.base64_encode($row['img']).'" height="100px" width="100px" class="img-thumbnail" />';
              }
          } else {
              // Display default image when no image is available
              echo '<img src='.base_url("images/DefaultPic.jpg").' height="100px" width="100px" class="img-thumbnail" />';
          }
        ?> 
   </a> 
   <h3 class="name" style="font-size: 25px; margin-top: 8px; font-family: 'Nunito', sans-serif;  font-weight: 900;">  
      
      <?php

      include('DbConnection.php');

      $sel = "SELECT * FROM users where id=$userID";
      $qur = mysqli_query($con, $sel);
      $result = mysqli_fetch_assoc($qur);
      ?>
      <?php echo $result['fname']; ?>
   </h3>

   </div>

   <nav class="navbar">
      <a href="<?php echo base_url().'index.php/AdminRedirect/admin'?>"><i class="fa fa-home"></i> <span>Home</span></a>
      <a href="<?php echo base_url().'index.php/AdminRedirect/userlist'?>"><i class="fa-solid fa-user"></i><span>User-List</span></a>
      <a href="<?php echo base_url().'index.php/AdminRedirect/news'?>"><i class="fa-solid fa-newspaper"></i><span>News</span></a>
      <a href="<?php echo base_url().'index.php/AdminRedirect/feedback'?>"><i class="fa-solid fa-comments"></i><span>Feedback-List</span></a>
      <button class="dropdown-btn"> <i class="fa fa-caret-down"></i>View Uploaded
      </button>
      <div class="dropdown-container">
      <a href="<?php echo base_url().'index.php/AdminRedirect/viewDocuments'?>"><i class="fa-solid fa-file"></i><span>Personal</span></a>
          <a href="<?php echo base_url().'index.php/AdminRedirect/result'?>"><i class="fa-solid fa-file"></i><span>Result</span></a>
          <a href="<?php echo base_url().'index.php/AdminRedirect/resume'?>"><i class="fa-solid fa-file"></i><span>Resume</span></a>
      </div>
      <button class="dropdown-btn"> <i class="fa fa-caret-down"></i>Settings
      </button>
      <div class="dropdown-container">
      <a href="<?php echo base_url().'index.php/Settings/basicdetails'?>"><i class="fas fa-user-edit"></i><span>Basic Details</span></a>
          <a href="<?php echo base_url().'index.php/Settings/editimg'?>"><i class="fas fa-image"></i><span>Edit Picture</span></a>
          <a href="<?php echo base_url().'index.php/Settings/changepassword'?>"><i class="fa fa-key" aria-hidden="true"></i><span>Change Password</span></a>
          <a href="<?php echo base_url().'index.php/Controller/Admin'?>"><i class="fas fa-user-edit"></i><span>Update Profile</span></a>
      </div>
   </nav>

</div>
<script src="<?= base_url('js/script.js');?>"></script>
<script>
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
</script>
</body>
</html>