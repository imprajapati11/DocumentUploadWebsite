<?php 
$userID=$this->session->userdata('user_id');
$isAdmin=$this->session->userdata('isAdmin');

if (!$isAdmin) {
  redirect('index.php/Controller/dashboard');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>HeavanSpacez Personal Document</title>

      <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
      <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
      <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
      <link rel="stylesheet" href="<?= base_url('assets/css/fontawesome.css');?>">
      <link rel="stylesheet" href="<?= base_url('assets/css/animated.css');?>">
      <link rel="stylesheet" href="<?= base_url('assets/css/owl.css');?>">
      
    <style>
table {
    margin-top: auto;

    padding: auto;
  border: 1px solid #ccc;
  border-collapse: collapse;
  width: 100%;
  table-layout: fixed;
  border-radius: 10px;
 margin-left: -50px;
  text-align: center;
  margin-bottom: 90px;
}

table caption {
  font-size: 2px;
  margin: .5em 0 .75em;
}

table tr {
  background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;
  font-size: 15px;;
}

table th,
table td {
  padding: .625em;
  text-align: center;
}

table th {
  font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;
}

@media screen and (max-width: 600px) {
  table {
    border: 0;
  }

  table caption {
    font-size: 1.3em;
  }
  
  table thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  
  table tr {
    border-bottom: 3px solid #ddd;
    display: block;
    margin-bottom: .625em;
  }
  
  table td {
    border-bottom: 1px solid #ddd;
    display: block;
    font-size: .8em;
    text-align: right;
  }
  
  table td::before {
    content: attr(data-label);
    float: left;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  table td:last-child {
    border-bottom: 0;
  }
}

body {
  font-family: "Open Sans", sans-serif;
  line-height: 1.25;
}
</style>
    </head>
<body style="background-color: #fff;">


<?php include('admin-header.php');?>
   <?php include('admin-sidebar.php');?> 

<h3 style="margin-top: 5.5em; text-align: center; font-size: 20px; margin-bottom: 25px;"><u style="text-decoration: underline;"> View Users Uploaded Document</u></h3>
<table>
    <tr>
        <th> No.</th>
        <th>User Name</th>
        <th>File Name</th>
        <th>Uplaod Date</th>
        <th>Action</th>
        <!--   -->
    </tr>
    <?php $i=1; foreach ($documents as $document) { ?>
        <tr>
            <td><?php echo $i; $i++;?>
            <td><?php echo $document->fname; ?></td>
            <td><?php echo $document->file_name; ?></td>
            <td><?php echo $document->upload_date; ?></td>
            <td>
            <!-- <a href="#" name="id" id="id"><i class="fa-solid fa-trash-can"></i></a> /  -->
            <a target="_blank" href="<?php echo base_url().'images/uploaded/'.$document->file_path; ?> "><i class="fa-solid fa-eye"></i></a>
            </td>

            <!-- <td><a href='get_city.php?id='>View</a></td> -->
          </tr>
          <?php } ?>
    
</table>

<?php 
$con -> close();
?>

<?php 
include("footer.php");
?>
</body>
</html>
