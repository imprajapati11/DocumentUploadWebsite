<?php
$hostname="localhost";
$username="root";
$password="";
$db_name="heavanspacez";

$con= mysqli_connect($hostname, $username, $password, $db_name);

?>   