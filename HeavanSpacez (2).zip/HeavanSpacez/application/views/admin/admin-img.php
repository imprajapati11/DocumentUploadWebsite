<?php 
$userID=$this->session->userdata('user_id');
$isAdmin=$this->session->userdata('isAdmin');

if (!$isAdmin) {
  redirect('index.php/Controller/dashboard');
}
?>
<?php  
 $connect = mysqli_connect("localhost", "root", "", "heavanspacez");  
 if(isset($_POST["insert"]))
 {  
 
     $sql = "SELECT * FROM `img` WHERE user_id=$userID";
     $res=mysqli_query($connect,$sql);

     if(mysqli_num_rows($res) > 0){
          $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
          $update= "UPDATE img SET img = '$file' WHERE user_id=$userID";
          if(mysqli_query($connect, $update)) {
          $this->session->set_flashdata('form_data',$_POST);
          $this->session->set_flashdata('updateImg','Image Sucessfully Updated :)');
          redirect(base_url().'index.php/Settings/editimg'); 
          }else{
               echo '<script>alert("Error")</script>';
          }
     }else{
     $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));  
      $query = "INSERT INTO img(img,user_id) VALUES ('$file','$userID')";  
      if(mysqli_query($connect, $query))  
      {  
          $this->session->set_flashdata('form_data',$_POST);
          $this->session->set_flashdata('insertImg','Image Sucessfully Inserted :)');
          redirect(base_url().'index.php/Settings/editimg'); 
      }  
 }  
}
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
             
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />   -->
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  

          <meta charset="UTF-8">
          <meta http-equiv="X-UA-Compatible" content="IE=edge">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>HeavanSpacez Edit Image</title>

      <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
      <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
      <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
      <!-- <link rel="stylesheet" href="<?= base_url('css/style.css');?>"> -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

     <style>
     input[type=submit] {
          width: 100%;
          background-color: var(--main-color);
          color: white;
          margin-top: 5px;
          padding: 15px 25px;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          float: right;
          font-size: 1.5em;
     }
  
     input[type=submit]:hover {
          background-color: var(--black);
     }
  </style>
      </head>  
      <body style="background-color: #fff;">  
          <?php 
          include("admin-header.php");?>
          <?php 
          include("admin-sidebar.php");
          ?>
           <br /><br />  
           <div class="form-container" style="width:500px;">  
                  
                <br />  
                <form method="post" enctype="multipart/form-data" style="background-color: #f2f2f2;">
                <h3 style="margin-bottom: 35px;">Upload Your Profile Picture</h3>   
                     <input type="file" name="image" id="image" style="font-size: 1.6em"/>  
                     <br />  
                     <input type="submit" name="insert" id="insert" value="Upload"/>  
                     <span style="margin-top: 5em; font-size: 1.5em;">
                         <?php if ($this->session->flashdata('updateImg')): ?>
                         <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-top: 4.5em; ">
                         <?php echo $this->session->flashdata('updateImg'); ?>
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">×</span>
                              </button>
                         </div>
                         <?php endif; ?>
                         <?php if ($this->session->flashdata('insertImg')): ?>
                         <div class="alert alert-success alert-dismissible fade show" role="alert" style="margin-top: 1em; ">
                         <?php echo $this->session->flashdata('insertImg'); ?>
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">×</span>
                              </button>
                         </div>
                         <?php endif; ?>
                     </span>
                     
                </form>  
                <br />  
                <br />  
                
           </div> 
           
          <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
          <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
          <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>


           <?php 
           include('footer.php');
           ?>
      </body>  
 </html>  
 <script>  
 $(document).ready(function(){  
      $('#insert').click(function(){  
           var image_name = $('#image').val();  
           if(image_name == '')  
           {  
                alert("Please Select Image");  
                return false;  
           }  
           else  
           {  
                var extension = $('#image').val().split('.').pop().toLowerCase();  
                if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
                {  
                     alert('Invalid Image File');  
                     $('#image').val('');  
                     return false;  
                }  
           }  
      });  
 });  
 </script>