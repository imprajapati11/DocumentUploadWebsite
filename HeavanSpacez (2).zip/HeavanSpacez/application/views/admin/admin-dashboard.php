<?php 
$userID=$this->session->userdata('user_id');
$isAdmin=$this->session->userdata('isAdmin');

if (!$isAdmin) {
  redirect('index.php/Controller/dashboard');
}
?>

<?php 
 if (!isset($_SESSION['randomNumber'])) {
  $_SESSION['randomNumber'] = rand(1000, 5000);
} else {
  $_SESSION['randomNumber']++;
}
$randomNumber = $_SESSION['randomNumber'];
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="refresh" content="900">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HeavanSpacez Admin Dashboard</title>
    <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
    <link rel="stylesheet" href="<?= base_url('css/style.css');?>"> 
    <link rel="stylesheet" href="<?= base_url('css/extracss.css');?>"> 
    
    <style>

      .img-thumbnail {
        padding: .25rem;
        background-color: #fff;
        border: 1px solid #dee2e6;
        border-radius: .25rem;
        max-width: 100%;
        height: auto;
        border-radius: 50%;
      }

      img {
        vertical-align: middle;
        border-style: none;
      }
      .display-4 {
          font-size: 3.5rem;
          font-weight: 300;
          line-height: 1.2;
      }

      .content {
        margin-left: -100px;
        margin-top: 8.5em;
        -webkit-transition: 0.2s all ease-in-out;
        transition: 0.2s all ease-in-out;
      }

      .content #navBtn {
        font-size: 20px;
      }

      .main.animate .content {
        margin-left: 60px;
      }

      .myBtn[aria-expanded="false"] .myCaret:before {
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        content: "f107";
        float: right;
        transition: all 0.5s;
      }

      .myBtn[aria-expanded="true"] .myCaret:before {
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        content: "f107";
        float: right;
        transition: all 0.5s;
        -webkit-transform: rotate(180deg);
        -moz-transform: rotate(180deg);
        transform: rotate(180deg);
      }

      @media (max-width: 991px) {
        .main .navbar-side {
          width: 40px;
          -webkit-transition: 0.2s all ease-in-out;
          transition: 0.2s all ease-in-out;
          font-size: 0.8em;
        }
        .main .navbar-side .link-text {
          display: none;
        }
        .main .navbar-side .caret {
          display: none;
        }
        .main .navbar-side h6 {
          margin: 9px 0 10px 9px;
          font-size: 1.2em;
          line-height: 1.9;
        }
        .main .navbar-side ul li a {
          padding-left: 10px;
        }
        .main .navbar-side ul li a:hover,
        .main .navbar-side ul li a.link-active {
          border-left: 2px solid #ccc;
        }
        .main .content {
          margin-left: 40px;
        }
        .main.animate .navbar-side {
          width: 150px;
          -webkit-transition: 0.2s all ease-in-out;
          transition: 0.2s all ease-in-out;
        }
        .main.animate .navbar-side .link-text {
          display: inline-block;
        }
        .main.animate .navbar-side .caret {
          display: block;
        }
        .main.animate .content {
          margin-left: 150px;
        }
        .myCaret {
          display: none;
        }
      }

      .sidenav a, .dropdown-btn {
        padding: 6px 8px 6px 16px;
        text-decoration: none;
        font-size: 18px;
        color: var(--light-color);
        background-color: transparent;
        display: block;
        border: none;
        background: none;
        width: 100%;
        text-align: left;
        cursor: pointer;
        outline: none;
      }

      /* On mouse-over */
      a:hover, .dropdown-btn:hover {
        color: var(--light-color);
        background-color: transparent;
      }

      .active {
        background-color: transparent;
        
      }

      .dropdown-container {
        display: none;
      width: 100%;
        padding-left: 8px;
      }
      .dropdown-container:hover {
        color: var(--light-color);
        background-color: transparent;
        padding-left: 8px;
      }

      .fa-caret-down {
        float: right;
        padding-right: 8px;
      } 


      .reviews-container {
        margin-left: -100px;
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        margin-bottom: 50px;
        
      }
      h2 {
          font-size: 2.5rem;
          margin-top: 3rem;
          margin-bottom: 5rem;
          text-align: center;
          color: var(--light-color);
      }

      .review {
        max-width: 400px;
        margin-bottom: 20px;
        padding: 20px;
        background-color: #f5f5f5;
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      }

      .avatar {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        object-fit: cover;
      }

      .name {
        margin-top: 10px;
        font-size: 18px;
        font-weight: bold;
      }

      .comment {
        margin-top: 10px;
        font-size: 14px;
        line-height: 1.5;
      }

      @media only screen and (max-width: 600px) {
        .reviews-container {
          margin-left: 0;
        }

        .review {
          max-width: 100%;
        }
      }


      .wrapper{
          position: relative;
          display: flex;
          justify-content: center;
          align-items: center;
      }
      .background-container{
          width: 100%;
          min-height: 60vh;
          display: flex; 
      }
      .bg-1{
          flex: 1;
      }
      .bg-2{
          flex: 1;
      }
      .about-container{
          width: 100%;
          margin-left: -50px;
          min-height: 50vh;
          position: absolute;
          background-color: #f5f5f5;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
          display: flex;
          justify-content: center;
          align-items: center;
          padding: 20px 40px;
          border-radius: 5px;
      }
      .image-container{
          flex: 1;
          display: flex;
          justify-content: center;
          align-items: center;
      }
      .image-container img {
          width: 500px;
          height: 500px;
          margin: 20px;
          border-radius: 10px;
      }
      .text-container{
          flex: 1;
          display: flex;
          justify-content: center;
          align-items: flex-start;
          flex-direction: column;
          font-size: 22px;
      }
      .text-container h1{
          font-size: 70px;
          padding: 20px 0px;
      }
      .text-container a{
          text-decoration: none;
          padding: 12px;
          margin: 50px 0px;
          background-color: rebeccapurple;
          border: 2px solid transparent;
          color: white;
          border-radius: 5px;
          transition: .3s all ease;
      }
      .text-container a:hover{
          background-color: transparent;
          color: black;
          border: 2px solid rebeccapurple;
      }
      @media screen and (max-width: 1600px){
          .about-container{
              width: 90%;
          }
          .image-container img{
              width: 400px;
              height: 400px;
          }
          .text-container h1{
              font-size: 50px;
          }
      }
      @media screen and (max-width: 1100px){
          .about-container{
              flex-direction: column;
          }
          .image-container img{
              width: 300px;
              height: 300px;
          }
          .text-container {
              align-items: center;
          }
      }

      
.message-pass {
  background-color: cyan;
  color: #333;
  display: block;
  font-weight: 900;
  overflow: hidden;
  position: absolute;
  padding-left: 0.5rem;
  top: 0.2rem;
  left: 270px;
  animation: openclose 5s ease-in-out infinite;
}

.word1, .word2, .word3 {
  font-family: poppins;
}

@keyframes openclose {
  /* 0% {
    top: 1rem;
    width: 0;
  }
  5% {
    width: 0;
  }
  15% {
    width: 230px;
  }
  30% {
    top: 1rem;
    width: 230px;
  }
  33% {
    top: 1rem;
    width: 0;
  }
  35% {
    top: 1rem;
    width: 0;
  }
  38% {
    top: -3.5rem;
    
  }
  48% {
    top: -3.5rem;
    width: 190px;
  }
  62% {
    top: -3.5rem;
    width: 190px;
  }
  66% {
    top: -3.5rem;
    width: 0;
    text-indent: 0;
  }
  71% {
    top: -9rem;
    width: 0;
    text-indent: 5px;
  }
  86% {
    top: -9rem;
    width: 285px;
  }
  95% {
    top: -9rem;
    width: 285px;
  }
  98% {
    top: -9rem;
    width: 0;
    text-indent: 5px;
  }
  100% {
    top: 0;
    width: 0;
    text-indent: 0;
  } */

  0% {
    top: 1rem;
    width: 0;
  }
  5% {
    width: 0;
  }
  15% {
    width: 230px;
  }
  30% {
    top: 1rem;
    width: 230px;
  }
  33% {
    top: 1rem;
    width: 0;
  }
  35% {
    top: 1rem;
    width: 0;
  }
  38% {
    top: -3.5rem;
  }
  48% {
    top: -3.5rem;
    width: 230px;
  }
  62% {
    top: -3.5rem;
    width: 230px;
  }
  66% {
    top: -3.5rem;
    width: 0;
    text-indent: 0;
  }
  71% {
    top: -9rem;
    width: 0;
    text-indent: 5px;
  }
  86% {
    top: -9rem;
    width: 230px;
  }
  95% {
    top: -9rem;
    width: 230px;
  }
  98% {
    top: -9rem;
    width: 0;
    text-indent: 5px;
  }
  100% {
    top: 0;
    width: 0;
    text-indent: 0;
  }
}

    </style>

  </head>
  <body style="background-color: #fff;">

  <div id="js-preloader" class="js-preloader">
      <div class="preloader-inner">
        <span class="dot"></span>
        <div class="dots">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
    </div>

  <?php include('admin-header.php');?>

  <div class="side-bar">

    <div id="close-btn">
        <i class="fas fa-times"></i>
    </div>

    <div class="profile">
        <a href="<?php echo base_url().'index.php/Settings/editimg'?>">
        <?php  
          $connect = mysqli_connect("localhost", "root", "", "heavanspacez");  
          $query = "SELECT * FROM img WHERE user_id='$userID'";  
          $result = mysqli_query($connect, $query);

          if (mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_array($result)) {
                  echo '<img src="data:image/jpeg;base64,'.base64_encode($row['img']).'" height="100px" width="100px" class="img-thumbnail" />';
              }
          } else {
              // Display default image when no image is available
              echo '<img src='.base_url("images/DefaultPic.jpg").' height="100px" width="100px" class="img-thumbnail" />';
          }
        ?>   
            </a>
        <h3 class="name">  
        
        <?php

        include('DbConnection.php');

        $sel = "SELECT * FROM users where id=$userID";
        $qur = mysqli_query($con, $sel);
        $result = mysqli_fetch_assoc($qur);
        ?>
        <p class="role" style="margin-top: 5px; margin-bottom: -1px;">Jay Shree Krishna <i class="fa-solid fa-hands-praying"></i></p>
        <h3 style="font-size: 25px; font-family: 'Nunito', sans-serif;  font-weight: 900;"><?php echo $result['fname']; ?>
        </div>

        <nav class="navbar" style=" margin-left: -10px;">
            <a href="<?php echo base_url().'index.php/AdminRedirect/admin'?>"><i class="fa fa-home"></i> <span>Home</span></a>
            <a href="<?php echo base_url().'index.php/AdminRedirect/userlist'?>"><i class="fa-solid fa-user"></i><span>User-List</span></a>
            <a href="<?php echo base_url().'index.php/AdminRedirect/news'?>"><i class="fa-solid fa-newspaper"></i><span>News</span></a>
            <a href="<?php echo base_url().'index.php/AdminRedirect/feedback'?>"><i class="fa-solid fa-comments"></i><span>Feedback</span></a>
            <button class="dropdown-btn"> <i class="fa fa-caret-down"></i>View Uploaded
            </button>
            <div class="dropdown-container">
            <a href="<?php echo base_url().'index.php/AdminRedirect/viewDocuments'?>"><i class="fa-solid fa-file"></i><span>Personal</span></a>
                <a href="<?php echo base_url().'index.php/AdminRedirect/result'?>"><i class="fa-solid fa-file"></i><span>Result</span></a>
                <a href="<?php echo base_url().'index.php/AdminRedirect/resume'?>"><i class="fa-solid fa-file"></i><span>Resume</span></a>
            </div>
            <button class="dropdown-btn"> <i class="fa fa-caret-down"></i>Settings
            </button>
            <div class="dropdown-container">
            <a href="<?php echo base_url().'index.php/Settings/basicdetails'?>"><i class="fas fa-user-edit"></i><span>Basic Details</span></a>
                <a href="<?php echo base_url().'index.php/Settings/editimg'?>"><i class="fas fa-image"></i><span>Change Image</span></a>
                <a href="<?php echo base_url().'index.php/Settings/changepassword'?>"><i class="fa fa-key" aria-hidden="true"></i><span>Change Password</span></a>
                <a href="<?php echo base_url().'index.php/Controller/Admin'?>"><i class="fas fa-user-edit"></i><span>Update Profile</span></a>
            </div>


        </nav>

  </div>

  <section class="home-grid">
    <div class="main">
    <div class="content">
    <div class="container-fluid">
      <h1 style="
   color: #333;
  font-family: tahoma;
  font-size: 3rem;
  font-weight: 100;
  line-height: 1.5;
  text-transform: uppercase;
  white-space: nowrap;
  overflow: hidden;
  position: relative;
  width: 550px;
   ">
  <span style="font-size: 40px; margin-left: 40px;">always be</span>
  <div class="message-pass">
    <div class="word1">Happy</div>
    <div class="word2">Positive</div>
    <div class="word3">Sanatan</div>
  </div>
</h1>
    <div class="row">

  <div class="col-lg-4 col-md-6 p-2" >
    <div class="card border-primary rounded-0" >
      <div class="card-header bg-primary rounded-0">
        <h5 class="card-title text-white mb-1" style="font-size: 15px;">Total User</h5>
      </div>
      <div class="card-body">
        <h1 class="display-4 font-weight-bold text-primary text-center"><i class="fa-solid fa-user"></i>
        <?php 
        include("DbConnection.php");

        $sql="SELECT count(*) FROM `users`";
        $result = $con->query($sql);

        while($row = mysqli_fetch_array($result)){
          echo "".$row['count(*)'];
        }
        $con->close();
        ?></h1>
      </div>
    </div>
  </div>

  <div class="col-lg-4 col-md-6 p-2">
    <div class="card border-success rounded-0">
      <div class="card-header bg-success rounded-0">
        <h5 class="card-title text-white mb-1" style="font-size: 15px;">Total Like</h5>
      </div>
      <div class="card-body">
        <h1 class="display-4 font-weight-bold text-success text-center"> <i class="fa-solid fa-heart"></i>
        <?php echo $randomNumber; ?>+
        </h1>
      </div>
    </div>
  </div>

  <div class="col-lg-4 p-2">
    <div class="card border-danger rounded-0">
      <div class="card-header bg-danger rounded-0">
        <h5 class="card-title text-white mb-1" style="font-size: 15px;">Total Feedback</h5>
      </div>
      <div class="card-body">
        <h1 class="display-4 font-weight-bold text-danger text-center"><i class="fa-solid fa-comments"></i>
          <?php 
  include("DbConnection.php");

  $sql = "SELECT count(*) FROM `feedback`";
  $result = $con->query($sql);

  while($row = mysqli_fetch_array($result)){
    echo "".$row['count(*)'];
  }
  $con -> close();
  ?>
  </h1>
      </div>
    </div>
  </div>

  </div>
          <div class="row">

            <div class="col-lg-4 col-md-6 p-2">
              <div class="card border-primary rounded-0">
                <div class="card-header bg-primary rounded-0">
                  <h5 class="card-title text-white mb-1" style="font-size: 15px;">Total Personal Document Uploaded</h5>
                </div>
                <div class="card-body">
                  <h1 class="display-4 font-weight-bold text-primary text-center"><i class="fa fa-file" aria-hidden="true"></i>
  <?php 
          include("DbConnection.php");

          $sql="SELECT count(*) FROM `goverment_file`";
          $result = $con->query($sql);

          while($row = mysqli_fetch_array($result)){
              echo "".$row['count(*)'];
          }
          $con->close();
          ?></h1>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 p-2">
              <div class="card border-success rounded-0">
                <div class="card-header bg-success rounded-0">
                  <h5 class="card-title text-white mb-1" style="font-size: 15px;">Total Resume Uploaded</h5>
                </div>
                <div class="card-body">
                  <h1 class="display-4 font-weight-bold text-success text-center">  <i class="fa fa-file" aria-hidden="true"></i>
  <?php
          include("DbConnection.php");
          $sql = " SELECT count(*) FROM resume";
          $result = $con->query($sql);

          while($row = mysqli_fetch_array($result)){
              echo "".$row['count(*)'];
          }
          $con->close();
          ?></h1>
                </div>
              </div>
            </div>

            <div class="col-lg-4 p-2">
              <div class="card border-danger rounded-0">
                <div class="card-header bg-danger rounded-0">
                  <h5 class="card-title text-white mb-1" style="font-size: 15px;">Total Result Uploaded</h5>
                </div>
                <div class="card-body">
                  <h1 class="display-4 font-weight-bold text-danger text-center"><i class="fa fa-file" aria-hidden="true"></i>
  <?php 
          include("DbConnection.php");

          $sql = "SELECT count(*) FROM `result`";
          $result = $con->query($sql);

          while($row = mysqli_fetch_array($result)){
              echo "".$row['count(*)'];
          }
          $con -> close();
          ?>
          </h1>
                </div>
              </div>
            </div>

          </div>


          <div class="row" style="margin-top: 20px;">
            <div class="col-lg-6 p-2">
              <div class="jumbotron rounded-0" style=" box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); style: border-radius: 10px">
                <h1 class="display-4"><i class="fa-solid fa-quote-left"></i> APJ Abdul Kalam</h1>
                <!-- <p class="lead">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Repudiandae, recusandae maiores
                </p> -->
                <hr class="my-4">
                <p style="font-size: 15px;"><i class="fa-solid fa-quote-left"></i> When your hopes and dreams and goals are dashed, search among the wreckage, you may find a golden opportunity hidden in the ruins. <i class="fa fa-quote-right" aria-hidden="true"></i></p>
                <!-- <a href="#" class="btn btn-primary btn-lg rounded-0">Learn More</a> -->
              </div>
            </div>
            <div class="col-lg-6 p-2">
              <div class="jumbotron rounded-0" style="  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); border-radius: 5px;">
                <h1 class="display-4"><i class="fa-solid fa-quote-left"></i> C. V. Raman</h1>
                <!-- <p class="lead">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Repudiandae, recusandae maiores
                </p> -->
                <hr class="my-4">
                <p style="font-size: 15px;"><i class="fa-solid fa-quote-left"></i> The essence of Science is independent thinking, hard work, and not equipment. When I got my Nobel Prize, I had spent hardly 200 rupees on my equipment. <i class="fa fa-quote-right" aria-hidden="true"></i></p>
                <!-- <a href="#" class="btn btn-primary btn-lg rounded-0">Learn More</a> -->
              </div>
            </div>
          </div>
        </div>
      </div>

          <h2> <i class="fa-solid fa-handshake"></i>  About us </h2>

      <div class="wrapper">

  <div class="background-container">
      <div class="bg-1"></div>
      <div class="bg-2"></div>

  </div>
  <div class="about-container">
      
      <div class="image-container">
          <img src="<?= base_url('assets/images/about-dec.png');?>" alt="">
          
      </div>

      <div class="text-container">
          <h1>About us</h1>
          <p style="font-size: 15px;">
  "HeavanSpacez is the ultimate destination for hassle-free document uploads. With our intuitive and user-friendly interface, uploading documents has never been easier. Our cutting-edge platform ensures seamless file organization and lightning-fast uploads, saving you time and effort. Experience the convenience of securely storing and accessing your important files anytime, anywhere. Trust HeavanSpacez for top-notch data protection, employing robust security measures to safeguard your confidential documents. Join our community of satisfied users and enjoy the best document uploading experience with HeavanSpacez."</p>
          <!-- <a href="">Read More</a> -->
      </div>
      
  </div>
  </div>

      <h2> <i class="fa-solid fa-handshake"></i>  Our Happy Clients </h2>

  <div class="reviews-container">


  <div class="review">
  <img src="<?= base_url('images/author-post.jpg');?>" alt="Customer 1" class="avatar">
  <h3 class="name">Krupali</h3>
  <p class="comment">"Excellent document storage website with user-friendly interface and robust security features, ensuring hassle-free file management and peace of mind."</p>
  </div>

  <div class="review">
  <img src="<?= base_url('images/Screenshot 2023-06-23 094657.png');?>" alt="Customer 2" class="avatar">
  <h3 class="name">Vrushabh</h3>
  <p class="comment">"Efficient and secure, the document storage website offers seamless organization and robust data protection, ensuring peace of mind for users."</p>
  </div>

  <div class="review">
  <img src="<?= base_url('images/profile.png');?>" alt="Customer 2" class="avatar">
  <h3 class="name">Meet</h3>
  <p class="comment">"Efficient and user-friendly, the document storage website offers seamless file organization and secure data storage, making it a reliable choice for users seeking a convenient and trustworthy platform."</p>
  </div>

  <div class="review">
  <img src="<?= base_url('images/Screenshot 2023-06-23 103608.png');?>" alt="Customer 2" class="avatar">
  <h3 class="name">Ankit</h3>
  <p class="comment">"The document storage website offers a user-friendly interface and efficient file management, making it a convenient choice for organizing and accessing important files."</p>
  </div>

  <div class="review">
  <img src="<?= base_url('images/Screenshot 2023-06-23 103946.png');?>" alt="Customer 2" class="avatar">
  <h3 class="name">Vishal</h3>
  <p class="comment">"While the website's storage capacity is impressive, occasional performance issues and limited customer support can be frustrating for users."</p>
  </div>

  <div class="review">
  <img src="<?= base_url('images/PngItem_6304991.png');?>" alt="Customer 2" class="avatar">
  <h3 class="name">Dizo</h3>
  <p class="comment">"I highly recommend the document storage website for its user-friendly interface and efficient file organization, making it a breeze to manage and access my documents."</p>
  </div>

  </div>

  </section>

        
  <?php 
  include("footer.php");
  ?>
  <script src="js/script.js"></script>

  <script>
  var dropdown = document.getElementsByClassName("dropdown-btn");
  var i;

  for (i = 0; i < dropdown.length; i++) {
    dropdown[i].addEventListener("click", function() {
      this.classList.toggle("active");
      var dropdownContent = this.nextElementSibling;
      if (dropdownContent.style.display === "block") {
        dropdownContent.style.display = "none";
      } else {
        dropdownContent.style.display = "block";
      }
    });
  }
  </script>

  <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/owl-carousel.js"></script>
    <script src="assets/js/animation.js"></script>
    <script src="assets/js/imagesloaded.js"></script>
    <script src="assets/js/custom.js"></script>

  </body>
</html>