<?php $userID=$this->session->userdata('user_id');?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>HeavanSpacez News List</title>
      <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
      <link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
      <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
      <link rel="stylesheet" href="<?= base_url('assets/css/fontawesome.css');?>">
      <link rel="stylesheet" href="<?= base_url('assets/css/animated.css');?>">
      <link rel="stylesheet" href="<?= base_url('assets/css/owl.css');?>">
    <style>
table {
    margin-top: auto;

    padding: auto;
  border: 1px solid #ccc;
  border-collapse: collapse;
  width: 100%;
  table-layout: fixed;
  border-radius: 10px;
 margin-left: -50px;
  text-align: center;
  margin-bottom: 90px;
}


table caption {
  font-size: 2px;
  margin: .5em 0 .75em;
}

table tr {
  background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;
  font-size: 13px;;
}

table th,
table td {
  padding: .625em;
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

table th {
  font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;
}

@media screen and (max-width: 600px) {
  table {
    border: 0;
  }

  table caption {
    font-size: 1.3em;
  }
  
  table thead {
    border: none;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
  }
  
  table tr {
    border-bottom: 3px solid #ddd;
    display: block;
    margin-bottom: .625em;
  }
  
  table td {
    border-bottom: 1px solid #ddd;
    display: block;
    font-size: 1em;
    text-align: right;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  
  table td::before {
    content: attr(data-label);
    float: left;
    font-weight: bold;
    text-transform: uppercase;
  }
  
  table td:last-child {
    border-bottom: 0;
  }
}

body {
  font-family: "Open Sans", sans-serif;
  line-height: 1.25;
}
</style>
    </head>
<body style="background-color: #fff;">


<?php include('admin-header.php');?>
   <?php include('admin-sidebar.php');?> 

   <?php 
include("DbConnection.php");

$sql = "SELECT * FROM `news`";
$result = $con->query($sql);
?>
<h3 style="margin-top: 140px; text-align: center; font-size: 20px; margin-bottom: 25px;"><u style="text-decoration: underline;"> News List</u></h3>
<table>
    <tr>
        <th>No.</th>
        <th>Heading</th>
        <th>Details</th>
        <th>Location</th>
        <th>Date</th>
        <th>additional information</th>
        <th>Edit Date</th>
        <th>Action</th>
    </tr>
    <?php $i=1; while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $i; $i++;?></td>
            <td><?php echo $row['header']?></td>
            <td><?php echo $row['information']; ?></td>
            <td><?php echo $row['location']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['extra'];?> </td>
            <td><?php echo $row['edit_date']; ?></td>
            <td>
                <?php $id = $row['id']; ?>
                <a href="<?php echo site_url('index.php/News/deletenews/'.$id); ?>"><i class="fa-solid fa-trash-can"></i></a> /
                <a href="<?php echo site_url('index.php/News/editnews/'.$id); ?>"><i class="fas fa-edit"></i></a>
            </td>
          </tr>
    <?php } ?>
</table>


<span><a href="<?php echo base_url().'index.php/News/newsadd'?>"> <button class="btn" style="width: 15%; text-align: center; margin-left: -50px; margin-top: -60px; margin-bottom: 90px;"><i class="fa-solid fa-plus"></i> Add News</button></a>
<!-- <a href="#"> <button class="btn" style="width: 15%; text-align: center; margin-left: -50px; margin-bottom: 150px;"><i class="fa fa-search" aria-hidden="true"></i> Find User</button></a> -->
</span>

<?php 
include("footer.php");
?>
</body>
</html>
