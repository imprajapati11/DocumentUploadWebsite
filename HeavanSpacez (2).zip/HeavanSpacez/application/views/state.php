<?php 
$hostname="localhost";
$username="root";
$password="";
$db_name="documentupload";

$conn= mysqli_connect($hostname, $username, $password, $db_name);

$country_id = $_POST['country_id'];
$query= "select * from states where country_id='".$country_id."' order by name ASC";
$result= mysqli_query($conn,$query);

while ($row= mysqli_fetch_array($result)) {
	?>
	<option value='<?php echo $row['id'] ?>'><?php echo $row['name']; ?></option>;
<?php } ?>