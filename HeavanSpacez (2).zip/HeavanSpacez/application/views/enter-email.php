<!DOCTYPE html>
<html lang="en">
<head>
	<title>HeavanSpacez Forgot</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="  https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
	
	<link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
	<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
	<link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
	<link rel="manifest" href="/site.webmanifest">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">


	<link rel="stylesheet" type="text/css" href="<?= base_url("vendor/bootstrap/css/bootstrap.min.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("fonts/font-awesome-4.7.0/css/font-awesome.min.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("fonts/Linearicons-Free-v1.0.0/icon-font.min.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("vendor/animate/animate.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("vendor/css-hamburgers/hamburgers.min.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("vendor/animsition/css/animsition.min.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("Vendor/select2/select2.min.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("vendor/daterangepicker/daterangepicker.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("css/util.css");?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url("css/main.css");?>">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">


<style>
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 120px;
  height: 120px;
  margin: -76px 0 0 -76px;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
.animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
}

@-webkit-keyframes animatebottom {
  from { bottom:-100px; opacity:0 } 
  to { bottom:0px; opacity:1 }
}

@keyframes animatebottom { 
  from{ bottom:-100px; opacity:0 } 
  to{ bottom:0; opacity:1 }
}

#myDiv {
  display: none;
  text-align: center;
}
</style>
</head>

<body style="margin:0;">



<div  class="animate-bottom">
	
	<div class="limiter">
		<div class="container-login100">
		<!-- <div class="container-login100" style="background-image: url('images/bg-01.jpg');"> -->
			<div class="wrap-login100 p-l-110 p-r-110 p-t-62 p-b-33" style="border: 20px;
            border: 2px solid black;
            border-radius: 50px;
			box-shadow: 1px 2px 3px 4px rgba(12,12,12,0.2);
			">
				<form class="login100-form validate-form flex-sb flex-w" onsubmit="return validateForm()"  action="<?php echo base_url().'index.php/ResetPasswordController/sendOTP'?>" method="POST">
					<span class="login100-form-title p-b-53">
                    <img src="<?= base_url("images/HS.png");?>"  style="  height: 90px;">
					</span>

					<span class="login100-form-title p-b-53">
						<?php if ($this->session->flashdata('userError')): ?>
							<div class="alert alert-danger alert-dismissible fade show" role="alert">
							<?php echo $this->session->flashdata('userError'); ?>
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
								</button>
							</div>
						<?php endif; ?>
						<?php if ($this->session->flashdata('notUser')): ?>
							<div class="alert alert-danger alert-dismissible fade show" role="alert">
							<?php echo $this->session->flashdata('notUser'); ?>
								<button type="button" class="close" data-dismiss="alert" aria-label="Close">
								<span aria-hidden="true">×</span>
								</button>
							</div>
						<?php endif; ?>
					</span>
			
					<div class="p-t-31 p-b-9" style="margin-top :-25px">
						<span class="txt1">
							Username
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Username is required">
						<input class="input100" type="text" id="email" name="email" placeholder="Enter EmailID">
						<span class="focus-input100"></span>
                        <span id="emailError" style="color: #8C2F00; font-size: 12px"></span>
					</div>
					<div class="container-login100-form-btn m-t-17">
						<button class="login100-form-btn" name="submit">
							Send
						</button>
						</div>	
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>

	</div>

<script>
	function validateEmail(email){
		var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
		return emailRegex.test(email);
	}

	function validateForm(){
		var email=document.getElementById("email").value;
		if(email === ""){
			document.getElementById("emailError").innerHTML = "**Email is Required.";
			return false;
		}else if(!validateEmail(email)){
			document.getElementById("emailError").innerHTML = "**Invalid email format";
			return false;
		}else{
			document.getElementById("emailError").innerHTML="";
		}
		return true;
	}

	
	document.getElementById("email").addEventListener("keyup", function () {
    validateForm();
  	});
    </script>
	<script src="<?= base_url("vendor/jquery/jquery-3.2.1.min.js");?>"></script>
	<script src="<?= base_url("vendor/animsition/js/animsition.min.js");?>"></script>
	<script src="<?= base_url("vendor/bootstrap/js/popper.js");?>"></script>
	<script src="<?= base_url("vendor/bootstrap/js/bootstrap.min.js");?>"></script>
	<script src="<?= base_url("vendor/daterangepicker/moment.min.js");?>"></script>
	<script src="<?= base_url("vendor/daterangepicker/daterangepicker.js");?>"></script>
	<script src="<?= base_url("vendor/countdowntime/countdowntime.js");?>"></script>
	<script src="<?= base_url("js/main.js");?>"></script>

	
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>


</body>
</html>