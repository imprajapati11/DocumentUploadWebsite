<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Source+Serif+Pro:400,600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('fonts/icomoon/style.css');?>">
    <link rel="stylesheet" href="<?= base_url('footer/css/bootstrap.min.css');?>">
    <link rel="stylesheet" href="<?= base_url('footer/css/style.css');?>">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>HeavanSpacez</title>
    <link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
	<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
	<link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">


    <link href="<?= base_url('vendor/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">

   
    <link rel="stylesheet" href="<?= base_url('assets/css/fontawesome.css');?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/templatemo-digimedia-v1.css');?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/animated.css');?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/owl.css');?>">

  </head>

<body>


  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  
  <header class="header-area header-sticky wow slideInDown" data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav class="main-nav">
            <!-- ***** Logo Start ***** -->
            <a href="<?php echo base_url(); ?>index.php/Welcome/index" class="logo">
           <img src="<?= base_url('images/HS.png');?>" style="  height: 70px;">
             
            </a>
            <ul class="nav">
              <li class="scroll-to-section"><a href="#top" class="active">Home</a></li>
              <li class="scroll-to-section"><a href="#about">About</a></li>
              <li class="scroll-to-section"><a href="#services">Services</a></li>
              <!-- <li class="scroll-to-section"><a href="#portfolio">Projects</a></li>
              <li class="scroll-to-section"><a href="#blog">Blog</a></li> -->
              <li class="scroll-to-section"><a href="#contact">Contact</a></li> 
              <li class="scroll-to-section"><div class="border-first-button"><a href="<?php echo base_url(); ?>index.php/LoginController/login"><i class="fa-solid fa-right-to-bracket"></i></a></div></li> 
            </ul>        
            <a class='menu-trigger'>
                <span>Menu</span>
            </a>
          </nav>
        </div>
      </div>
    </div>
  </header>
  <div class="main-banner wow fadeIn" id="top" data-wow-duration="1s" data-wow-delay="0.5s">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="row">
            <div class="col-lg-6 align-self-center">
              <div class="left-content show-up header-text wow fadeInLeft" data-wow-duration="1s" data-wow-delay="1s">
                <div class="row">
                  <div class="col-lg-12">
                    <h2>Digital Document Store</h2>
                    <p>"The man who does not read books has no advantage over the one who cannot read them."</p>
                  </div>
                  <div class="col-lg-12">
                    <div class="border-first-button scroll-to-section">
                      <a href="<?php echo base_url(); ?>index.php/LoginController/login">Store Document</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="right-image wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
                <img src="<?= base_url('images/student.png');?>" alt="">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="about" class="about section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="row">
            <div class="col-lg-6">
              <div class="about-left-image  wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.5s">
                <img src="<?= base_url('assets/images/about-dec.png');?>" alt="">
              </div>
            </div>
            <div class="col-lg-6 align-self-center  wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
              <div class="about-right-content">
                <div class="section-heading">
                  <h6>About Us</h6>
                  <h4>Who is Heavan<em>Spacez</em></h4>
                  <div class="line-dec"></div>
                </div>
                <p>Our website aims to provide a secure and convenient platform for users to store and manage their important documents. With advanced encryption technology, we ensure the privacy and protection of user data. Our user-friendly interface allows for easy uploading, organizing, and accessing documents from anywhere at any time. Experience peace of mind knowing that your valuable documents are stored safely and readily accessible whenever you need them. Simplify your document management with our reliable and efficient document store website.</p>
                <div class="row">
                  <div class="col-lg-4 col-sm-4">
                    <div class="skill-item first-skill-item wow fadeIn" data-wow-duration="1s" data-wow-delay="0s">
                      <div class="progress" data-percentage="90">
                        <span class="progress-left">
                          <span class="progress-bar"></span>
                        </span>
                        <span class="progress-right">
                          <span class="progress-bar"></span>
                        </span>
                        <div class="progress-value">
                          <div>
                            90%<br>
                            <span>Personal Document</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-sm-4">
                    <div class="skill-item second-skill-item wow fadeIn" data-wow-duration="1s" data-wow-delay="0s">
                      <div class="progress" data-percentage="80">
                        <span class="progress-left">
                          <span class="progress-bar"></span>
                        </span>
                        <span class="progress-right">
                          <span class="progress-bar"></span>
                        </span>
                        <div class="progress-value">
                          <div>
                            80%<br>
                            <span>Result</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 col-sm-4">
                    <div class="skill-item third-skill-item wow fadeIn" data-wow-duration="1s" data-wow-delay="0s">
                      <div class="progress" data-percentage="80">
                        <span class="progress-left">
                          <span class="progress-bar"></span>
                        </span>
                        <span class="progress-right">
                          <span class="progress-bar"></span>
                        </span>
                        <div class="progress-value">
                          <div>
                            80%<br>
                            <span>Resume</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div> 
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="services" class="services section">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="section-heading  wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.5s">
            <h6>Our Services</h6>
            <h4>What Our Website <em>Provides</em></h4>
            <div class="line-dec"></div>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="naccs">
            <div class="grid">
              <div class="row">
                <div class="col-lg-12">
                  <div class="menu">
                    <div class="first-thumb active">
                      <div class="thumb">
                        <span class="icon"><img src="<?= base_url('assets/images/service-icon-01.png');?>" alt=""></span>
                        Document store
                      </div>
                    </div>
                    <div>
                      <div class="thumb">                 
                        <span class="icon"><img src="<?= base_url('assets/images/service-icon-02.png');?>" alt=""></span>
                        View
                      </div>
                    </div>
                    <div>
                      <div class="thumb">                 
                        <span class="icon"><img src="<?= base_url('assets/images/service-icon-03.png');?>" alt=""></span>
                        Download
                      </div>
                    </div>
                    <div>
                      <div class="thumb">                 
                        <span class="icon"><img src="<?= base_url('assets/images/service-icon-04.png');?>" alt=""></span>
                        Edit your Profile
                      </div>
                    </div>
                    </div>
                  </div>
                </div> 
                <div class="col-lg-12">
                  <ul class="nacc">
                    <li class="active">
                      <div>
                        <div class="thumb">
                          <div class="row">
                            <div class="col-lg-6 align-self-center">
                              <div class="left-text">
                                <h4>Personal Document Store</h4>
                                <p>Our website offers a trusted and secure platform for storing and managing important government documents. With strict adherence to data protection regulations, we prioritize the confidentiality and integrity of sensitive information. Our user-friendly interface simplifies the process of uploading, organizing, and retrieving government documents with ease.</p>
                                <div class="ticks-list"><span><i class="fa fa-check"></i> Aadhar Card</span> <span><i class="fa fa-check"></i> Pan Card</span> <span><i class="fa fa-check"></i> Birth Certificate</span>
                                  <span><i class="fa fa-check"></i> Death Certificate</span> <span><i class="fa fa-check"></i> Mediclaim</span></div>
                                <a href="<?php echo base_url(); ?>index.php/LoginController/login"><p>If you Try?</p></a>

                              </div>
                            </div>
                            <div class="col-lg-6 align-self-center">
                              <div class="right-image">
                                <img src="<?= base_url('assets/images/services-image.jpg');?>" alt="">
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>          
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <footer class="footer-59391" id="contact">
        <div class="border-bottom pb-5 mb-4">
          <div class="container">
            <div class="row align-items-center">
              <div class="col-lg-3">
                <form action="#" class="subscribe mb-4 mb-lg-0">
                  <div class="form-group">
                  <input type="email" class="form-control" placeholder="Enter your email">
                  <button><span class="icon-keyboard_backspace"></span></button><br>
                  <a href = "mailto:info@heavanspacez.com?subject = Feedback&body = Message"><span>
                  <i class="fa fa-envelope" aria-hidden="true"></i>  info@heavanspacez.com</span></a><br><br>
                  <span><i class="fa fa-phone" aria-hidden="true"></i> +91-123456789</span>
                  </div>
                </form>
              </div>
              <div class="col-lg-6 text-lg-center">
                <ul class="list-unstyled nav-links nav-left mb-4 mb-lg-0">
                  <li><a href="#">Features</a></li>
                  <li><a href="#">Blog</a></li>
                  <li><a href="#">Pricing</a></li>
                  <li><a href="#services">Services</a></li>
                </ul>
              </div>
              <div class="col-lg-3">
                <ul class="list-unstyled nav-links social nav-right text-lg-right">
                  <li><a href="https://www.instagram.com/_imprajapati11_/" target="_blank"><span><i class="fa-brands fa-instagram"></i></span></a></li>
                  <li><a href="https://www.linkedin.com/in/imprajapati11/?originalSubdomain=in" target="_blank"><span><i class="fa fa-linkedin" aria-hidden="true"></i></span></a></li>
                  <li><a href="https://m.facebook.com/profile.php?id=100007425617660" target="_blank"><span><i class="fa-brands fa-facebook-f"></i></span></a></li>
                  <li><a href="https://github.com/imprajapati" target="_blank"><span><i class="fa-brands fa-github"></i></span></a ></li>
                  <li></li>
                  <br>
                  <li></li><br>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div class="container">
          <div class="row align-items-center">
            <div class="col-lg-4 text-lg-center site-logo order-1 order-lg-2 mb-3 mb-lg-0">
              <a href="<?php echo base_url(); ?>index.php/Welcome/index" class="m-0 p-0"><img src="<?= base_url('images/HS.png');?>" style="  height: 50px;"></a>
            </div>
            <div class="col-lg-4 order-2 order-lg-1 mb-3 mb-lg-0">
              <ul class="list-unstyled nav-links m-0 nav-left">
                <li><a href="#">Terms</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Privacy</a></li>
                <li><a href="#">Contact</a></li>
              </ul>
            </div>
            
            <div class="col-lg-4 text-lg-right order-3 order-lg-3">
              <p class="m-0 text-muted"><small>&copy; 2023. All Rights Reserved.</small></p>
            </div>
          </div>
        </div>

    </footer>

  <script src="<?= base_url('vendor/jquery/jquery.min.js');?>"></script>
  <script src="<?= base_url('vendor/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
  <script src="<?= base_url('assets/js/owl-carousel.js');?>"></script>
  <script src="<?= base_url('assets/js/animation.js');?>"></script>
  <script src="<?= base_url('assets/js/imagesloaded.js');?>"></script>
  <script src="<?= base_url('assets/js/custom.js');?>"></script>

 

</body>
</html>