<!DOCTYPE html>
<html lang="en">
<head>
	<title>HeavanSpacez Signup</title>
	<link rel="apple-touch-icon" sizes="180x180" href="<?= base_url('images/apple-touch-icon.png');?>">
	<link rel="icon" type="image/png" sizes="32x32" href="<?= base_url('images/favicon-32x32.png');?>">
	<link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('images/favicon-16x16.png');?>">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="  https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">


	<link rel="stylesheet" type="text/css" href="<?= base_url("css/util.css");?>">
	<!-- <link rel="stylesheet" type="text/css" href="<?= base_url("css/main.css");?>"> -->


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            // Show the message for 3 seconds
            setTimeout(function() {
                $("#checkmsg").fadeOut("slow");
            }, 3000);
        });
    </script>

<style>



/*---------------------------------------------*/


a {
	font-family: Poppins-Regular;
	font-size: 14px;
	line-height: 1.7;
	color: #666666;
	margin: 0px;
	transition: all 0.4s;
	-webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
}

a:focus {
	outline: none !important;
}

a:hover {
	text-decoration: none;
  color: #fc00ff;
  border-color: #fc00ff;
}

/*---------------------------------------------*/
h1,h2,h3,h4,h5,h6 {
	margin: 0px;
}

p {
	font-family: Poppins-Regular;
	font-size: 14px;
	line-height: 1.7;
	color: #666666;
	margin: 0px;
}

ul, li {
	margin: 0px;
	list-style-type: none;
}


/*---------------------------------------------*/
input,select {
	outline: none;
	border: none;
}

textarea,select {
  outline: none;
  border: none;
}

textarea:focus ,select:focus, input:focus {
  border-color: transparent !important;
}

input:focus::-webkit-input-placeholder { color:transparent; }
input:focus:-moz-placeholder { color:transparent; }
input:focus::-moz-placeholder { color:transparent; }
input:focus:-ms-input-placeholder { color:transparent; }

textarea:focus::-webkit-input-placeholder { color:transparent; }
textarea:focus:-moz-placeholder { color:transparent; }
textarea:focus::-moz-placeholder { color:transparent; }
textarea:focus:-ms-input-placeholder { color:transparent; }

input::-webkit-input-placeholder { color: #555555;}
input:-moz-placeholder { color: #555555;}
input::-moz-placeholder { color: #555555;}
input:-ms-input-placeholder { color: #555555;}

textarea::-webkit-input-placeholder { color: #555555;}
textarea:-moz-placeholder { color: #555555;}
textarea::-moz-placeholder { color: #555555;}
textarea:-ms-input-placeholder { color: #555555;}

select:focus::-webkit-input-placeholder { color:transparent; }
select:focus:-moz-placeholder { color:transparent; }
select:focus::-moz-placeholder { color:transparent; }
select:focus:-ms-input-placeholder { color:transparent; }

select::-webkit-input-placeholder { color: #555555;}
select:-moz-placeholder { color: #555555;}
select::-moz-placeholder { color: #555555;}
select:-ms-input-placeholder { color: #555555;}

label {
  display: block;
  margin: 0;
}

/*---------------------------------------------*/
button {
	outline: none !important;
	border: none;
	background: transparent;
}

button:hover {
	cursor: pointer;
}

iframe {
	border: none !important;
}


/*//////////////////////////////////////////////////////////////////
[ Utility ]*/
.txt1 {
  font-family: Montserrat-SemiBold;
  font-size: 16px;
  color: #555555;
  line-height: 1.5;
}

.txt2 {
  font-family: Poppins-Regular;
  font-size: 14px;
  color: #999999;
  line-height: 1.5;
}

.limiter {
  width: 100%;
  margin: 0 auto;
  border-color: #333333;
}

.container-login100 {
  width: 100%;  
  min-height: 100vh;
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  padding: 15px;
  background-image: url('images/bg-01.jpg');
  background-position: center;
  background-size: cover;
  background-repeat: no-repeat;
}


.wrap-login100 {
  width: 900px;
  border-color: #333333;
  background: #fff;
  
  position: relative;

}


/*==================================================================
[ Form ]*/

.login100-form {
  width: 100%;
  
}

.login100-form-title {
  width: 100%;
  margin-bottom: -30px;

} 

/*------------------------------------------------------------------
[ Button sign in with ]*/
.btn-face,
.btn-google {
  font-family: Montserrat-SemiBold;
  font-size: 18px;
  line-height: 1.2;

  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 15px;
  width: calc((100% - 20px) / 2);
  height: 70px;
  border-radius: 10px;
  box-shadow: 0 1px 5px 0px rgba(0, 0, 0, 0.2);
  -moz-box-shadow: 0 1px 5px 0px rgba(0, 0, 0, 0.2);
  -webkit-box-shadow: 0 1px 5px 0px rgba(0, 0, 0, 0.2);
  -o-box-shadow: 0 1px 5px 0px rgba(0, 0, 0, 0.2);
  -ms-box-shadow: 0 1px 5px 0px rgba(0, 0, 0, 0.2);
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
  position: relative;
  z-index: 1;
}

.btn-google::before,
.btn-face::before {
  content: "";
  display: block;
  position: absolute;
  z-index: -1;
  width: 100%;
  height: 100%;
  border-radius: 10px;
  top: 0;
  left: 0;
  background: #a64bf4;
  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);
  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);
  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);
  background: linear-gradient(45deg, #00dbde, #fc00ff);
  opacity: 0;
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
}

.btn-face {
  color: #fff;
  background-color: #3b5998;
}

.btn-face i {
  font-size: 30px;
  margin-right: 17px;
  padding-bottom: 3px;
}

.btn-google {
  color: #555555;
  background-color: #fff;
}

.btn-google img {
  width: 30px;
  margin-right: 15px;
  padding-bottom: 3px;
}

.btn-face:hover:before,
.btn-google:hover:before {
  opacity: 1;
}

.btn-face:hover,
.btn-google:hover {
  color: #fff;
}


/*------------------------------------------------------------------
[ Input ]*/

.wrap-input100 {
  /* width: 100%; */
  position: relative;
  background-color: #f7f7f7;
  border: 1px solid #e6e6e6;
  border-radius: 10px;
  margin: 5px;
  margin-bottom: 15px;
  width: calc(100% / 2 - 20px);
  
}


/*---------------------------------------------*/
.input100,select {
    
  font-family: Poppins-Regular;
  color: #333333;
  line-height: 1.2;
  font-size: 18px;
  display: block;
  width: 100%;
  background: transparent;
  height: 60px;
  margin: 2px;
  padding: 0 20px;
}
/*------------------------------------------------------------------
[ Focus Input ]*/

.focus-input100 {
  position: absolute;
  display: block;
  width: calc(100% + 2px);
  height: calc(100% + 2px);
  top: -1px;
  left: -1px;
  pointer-events: none;
  border: 1px solid #fc00ff;
  border-radius: 10px;

  visibility: hidden;
  opacity: 0;

  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;

  -webkit-transform: scaleX(1.1) scaleY(1.3);
  -moz-transform: scaleX(1.1) scaleY(1.3);
  -ms-transform: scaleX(1.1) scaleY(1.3);
  -o-transform: scaleX(1.1) scaleY(1.3);
  transform: scaleX(1.1) scaleY(1.3);
}

.input100:focus + .focus-input100 {
  visibility: visible;
  opacity: 1;

  -webkit-transform: scale(1);
  -moz-transform: scale(1);
  -ms-transform: scale(1);
  -o-transform: scale(1);
  transform: scale(1);
}

.eff-focus-selection {
  visibility: visible;
  opacity: 1;

  -webkit-transform: scale(1);
  -moz-transform: scale(1);
  -ms-transform: scale(1);
  -o-transform: scale(1);
  transform: scale(1);
}


/*------------------------------------------------------------------
[ Button ]*/
.container-login100-form-btn {
  width: 100%;
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  flex-wrap: wrap;
}

.login100-form-btn {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0 20px;
  width: 100%;
  height: 60px;
  background-color: #333333;
  border-radius: 10px;

  font-family: Poppins-Medium;
  font-size: 16px;
  color: #fff;
  line-height: 1.2;

  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
  position: relative;
  z-index: 1;
}

.login100-form-btn::before {
  content: "";
  display: block;
  position: absolute;
  z-index: -1;
  width: 100%;
  height: 100%;
  border-radius: 10px;
  top: 0;
  left: 0;
  background: #a64bf4;
  background: -webkit-linear-gradient(45deg, #00dbde, #fc00ff);
  background: -o-linear-gradient(45deg, #00dbde, #fc00ff);
  background: -moz-linear-gradient(45deg, #00dbde, #fc00ff);
  background: linear-gradient(45deg, #00dbde, #fc00ff);
  opacity: 0;
  -webkit-transition: all 0.4s;
  -o-transition: all 0.4s;
  -moz-transition: all 0.4s;
  transition: all 0.4s;
}

.login100-form-btn:hover:before {
  opacity: 1;
}



/* Center the loader */
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 120px;
  height: 120px;
  margin: -76px 0 0 -76px;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Add animation to "page content" */
.animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
}

@-webkit-keyframes animatebottom {
  from { bottom:-100px; opacity:0 } 
  to { bottom:0px; opacity:1 }
}

@keyframes animatebottom { 
  from{ bottom:-100px; opacity:0 } 
  to{ bottom:0; opacity:1 }
}

#myDiv {
  display: none;
  text-align: center;
}
</style>

</head>
<body  style="margin:0;">


<div class="animate-bottom">
	<div class="limiter">
		<div class="container-login100">
       
			<div class="wrap-login100 p-l-110 p-r-110 p-t-62 p-b-33" style="border: 20px;
            border: 2px solid black;
            border-radius: 50px;
            box-shadow: 1px 2px 3px 4px rgba(12,12,12,0.2) ;" >

            <?php 
            echo form_open('index.php/RegisterController/process',['class'=>'login100-form validate-form flex-sb flex-w','onsubmit'=>'return verifyForm()']);
            ?>
				<!-- <form class="login100-form validate-form flex-sb flex-w" onsubmit="return verifyForm()" action="" method="POST""> -->
					<span class="login100-form-title p-b-53">
          <img src="<?= base_url("images/HS.png")?>" style="  height: 90px;"> 
          </span>
          <span class="login100-form-title p-b-53">
            <?php if ($this->session->flashdata('message')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <?php echo $this->session->flashdata('message'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                </div>
            <?php endif; ?>
            <?php if ($this->session->flashdata('smessage')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                  <?php echo $this->session->flashdata('smessage'); ?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">×</span>
                    </button>
                </div>
                <?php endif; ?>
          </span>
					
                     
					<div class="wrap-input100 validate-input" s>
						<input class="input100" type="text" name="fname" id="fname" placeholder="Enter your First Name">
						<span class="focus-input100"></span>
                        <span id="ferror" style="color: #8C2F00; font-size: 0.8em;"></span>
					</div>

					<div class="wrap-input100 validate-input" >
                    <input class="input100" type="text" name="lname" id="lname" placeholder="Enter your Last Name">
                    <span class="focus-input100"></span>
                    <span id="lerror" style="color: #8C2F00; font-size: 0.8em;"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<input class="input100" type="text" name="phoneno" id="phoneno" placeholder="Enter your Mobile Number">
						<span class="focus-input100"></span>
                    <span id="phonenoerror" style="color: #8C2F00; font-size: 0.8em;"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<input class="input100" type="text" name="email" id="email" placeholder="Enter your Email">
						<span class="focus-input100"></span>
                    <span id="emailerror" style="color: #8C2F00; font-size: 0.8em;"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<input class="input100" type="password" name="password" id="password"  placeholder="Enter your Password">
						<span class="focus-input100"></span>
                    <span id="pwderror" style="color: #8C2F00; font-size: 0.8em;"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<input class="input100" type="password" name="cpassword" id="cpassword" placeholder="Enter your Confirm Password">
						<span class="focus-input100"></span>
                        <span id="cpwderror" style="color: #8C2F00; font-size: 0.8em;"></span>
					</div>

                    
          <div class="wrap-input100 validate-input" >
                    <select name="country" id="country" class="form-control" style="background-color:transparent; border:none;">
                        <option value="">Select country</option>
                        <?php foreach ($countries as $country) : ?>
                            <option value="<?php echo $country['id']; ?>"><?php echo $country['name']; ?></option>
                        <?php endforeach; ?>
                    </select>
          </div>

          <div class="wrap-input100 validate-input">
                    <select name="state" id="state" class="form-control" style="background-color:transparent; border:none;">
                        <option value="">Select state</option>
                    </select>
          </div>


          <div class="wrap-input100 validate-input" style="width: 100%;">
                    <select name="city" id="city" class="form-control" style="background-color:transparent; border:none;">
                        <option value="">Select city</option>
                    </select>
          </div>



					<div class="container-login100-form-btn m-t-17">
						<button class="login100-form-btn" id="submit" name="submit">
							Done
						</button>
					</div>


                   <div class="w-full text-center p-t-55">
                        <span class="txt2"  ">
                          Back to 
                        </span>

						<a href="<?php echo base_url('index.php/LoginController/login')?>" class="txt2 bo1" ">
							Sign in
						</a>
				   </div>
                   
					
        
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>

	</div>
	<script src="<?= base_url("vendor/jquery/jquery-3.2.1.min.js");?>"></script>
	<script src="<?= base_url("vendor/animsition/js/animsition.min.js");?>"></script>
	<script src="<?= base_url("vendor/bootstrap/js/popper.js");?>"></script>
	<script src="<?= base_url("vendor/bootstrap/js/bootstrap.min.js");?>"></script>
	<script src="<?= base_url("vendor/daterangepicker/moment.min.js");?>"></script>
	<script src="<?= base_url("vendor/daterangepicker/daterangepicker.js");?>"></script>
	<script src="<?= base_url("vendor/countdowntime/countdowntime.js");?>"></script>
	<script src="<?= base_url("js/main.js");?>"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>

<script>
  function verifyForm() {
    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    var phoneno = document.getElementById("phoneno").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var cpassword = document.getElementById("cpassword").value;

    document.getElementById("ferror").innerHTML = "";
    document.getElementById("lerror").innerHTML = "";
    document.getElementById("phonenoerror").innerHTML = "";
    document.getElementById("emailerror").innerHTML = "";
    document.getElementById("pwderror").innerHTML = "";
    document.getElementById("cpwderror").innerHTML = "";

    // check empty fields
    if (fname === "") {
      document.getElementById("ferror").innerHTML = "**Fill in the Firstname, please!";
      return false;
    }
    var namePattern = /^[a-zA-Z ]+$/;
    if (!namePattern.test(fname)) {
      document.getElementById("ferror").innerHTML = "*First name must contain only alphabets.";
    }

    if (lname === "") {
      document.getElementById("lerror").innerHTML = "**Fill in the Lastname, please!";
      return false;
    }
    var lnamePattern = /^[a-zA-Z ]+$/;
    if (!lnamePattern.test(lname)) {
      document.getElementById("lerror").innerHTML = "*Last name must contain only alphabets.";
    }

    if (phoneno === "") {
      document.getElementById("phonenoerror").innerHTML = "**Fill in the Phone Number, please!";
      return false;
    }
    var regex = /^\d{10}$/;
    if (!regex.test(phoneno)) {
      document.getElementById("phonenoerror").innerHTML = "**Invalid phone number format.";
    }

    if (email === "") {
      document.getElementById("emailerror").innerHTML = "**Fill in the Email, please!";
      return false;
    }
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      document.getElementById("emailerror").innerHTML = "**Invalid email format.";
    }

    if (password === "") {
      document.getElementById("pwderror").innerHTML = "**Fill in the Password, please!";
      return false;
    }
    if (cpassword === "") {
      document.getElementById("cpwderror").innerHTML = "**Fill in the Confirm Password, please!";
      return false;
    }
    if (password !== cpassword) {
      document.getElementById("cpwderror").innerHTML = "*Passwords do not match.";
    }

    return true;
  }

  // Event listeners for input validation
  document.getElementById("fname").addEventListener("keyup", function(event) {
    var fname = event.target.value;
    var namePattern = /^[a-zA-Z ]+$/;
    if (!namePattern.test(fname)) {
      document.getElementById("ferror").innerHTML = "*First name must contain only alphabets.";
    } else {
      document.getElementById("ferror").innerHTML = "";
    }
  });

  document.getElementById("lname").addEventListener("keyup", function(event) {
    var lname = event.target.value;
    var lnamePattern = /^[a-zA-Z ]+$/;
    if (!lnamePattern.test(lname)) {
      document.getElementById("lerror").innerHTML = "*Last name must contain only alphabets.";
    } else {
      document.getElementById("lerror").innerHTML = "";
    }
  });

  document.getElementById("phoneno").addEventListener("keyup", function(event) {
    var phoneno = event.target.value;
    var regex = /^\d{10}$/;
    if (!regex.test(phoneno)) {
      document.getElementById("phonenoerror").innerHTML = "**Invalid phone number format.";
    } else {
      document.getElementById("phonenoerror").innerHTML = "";
    }
  });

  document.getElementById("email").addEventListener("keyup", function(event) {
    var email = event.target.value;
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      document.getElementById("emailerror").innerHTML = "**Invalid email format.";
    } else {
      document.getElementById("emailerror").innerHTML = "";
    }
  });

  document.getElementById("password").addEventListener("keyup", function(event) {
    var password = event.target.value;
    if (password === "") {
      document.getElementById("pwderror").innerHTML = "**Fill in the Password, please!";
    } else {
      document.getElementById("pwderror").innerHTML = "";
    }
  });

  document.getElementById("cpassword").addEventListener("keyup", function(event) {
    var cpassword = event.target.value;
    var password = document.getElementById("password").value;
    if (cpassword === "") {
      document.getElementById("cpwderror").innerHTML = "**Fill in the Confirm Password, please!";
    } else if (password !== cpassword) {
      document.getElementById("cpwderror").innerHTML = "*Passwords do not match.";
    } else {
      document.getElementById("cpwderror").innerHTML = "";
    }
  });
</script>


<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $("#country").change(function() {
            var countryId = $(this).val();
            $.ajax({
                url: "<?php echo base_url('index.php/LocationController/getStates'); ?>",
                type: "POST",
                data: {
                    country_id: countryId
                },
                dataType: "json",
                success: function(data) {
                    var options = '<option value="">Select state</option>';
                    data.forEach(function(state) {
                        options += '<option value="' + state.id + '">' + state.name + '</option>';
                    });
                    $("#state").html(options);
                    $("#city").html('<option value="">Select city</option>');
                }
            });
        });

        $("#state").change(function() {
            var stateId = $(this).val();
            $.ajax({
                url: "<?php echo base_url('index.php/LocationController/getCities'); ?>",
                type: "POST",
                data: {
                    state_id: stateId
                },
                dataType: "json",
                success: function(data) {
                    var options = '<option value="">Select city</option>';
                    data.forEach(function(city) {
                        options += '<option value="' + city.name + '">' + city.name + '</option>';
                    });
                    $("#city").html(options);
                }
            });
        });
    });
</script>